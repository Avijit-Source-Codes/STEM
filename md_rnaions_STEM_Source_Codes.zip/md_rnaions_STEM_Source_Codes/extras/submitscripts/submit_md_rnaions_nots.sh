#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module load intel/2015.02

JOBNAME=script_md_rnaions
QUEUE=commons
export NODES=1
PPN=16
WALLTIME=86400

WORKDIR=`pwd`
WALLTIME_M=`awk 'BEGIN {print '$WALLTIME'/60}'`

export PROCS=`awk 'BEGIN {print '$NODES'*'$PPN'}'`

SCRIPT=script_md_rnaions_nots.sh
export EXE=~/Programs/md_rnaions/src/md_rnaions.cex

for i in 1 2 3 4 5 6 7 8
do

export INPUT=PK4b_$i.mdp
QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$NODES --ntasks-per-node=$PPN --time=$WALLTIME_M --workdir=$WORKDIR --export=ALL"
JOBID=`sbatch $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`

done
