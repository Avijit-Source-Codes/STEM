#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module load ibm
module load openmpi/1.6.5-ibm

JOBNAME=script_md_rnaions_biou
QUEUE=serial
export NODES=1
PPN=32
# WALLTIME=28800
# WALLTIME=2880
WALLTIME=600
# WALLTIME=39600
# WALLTIME=43200
# WALLTIME=36000

WORKDIR=`pwd`

export PROCS=`awk 'BEGIN {print '$NODES'*'$PPN'}'`

SCRIPT=script_md_rnaions_biou.sh
export INPUT=input/DCA_5.mdp
QSUBOPTIONS="-N $JOBNAME -q $QUEUE -l nodes=$NODES:ppn=$PPN,walltime=$WALLTIME -d $WORKDIR -V"
JOBID=`qsub $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`
