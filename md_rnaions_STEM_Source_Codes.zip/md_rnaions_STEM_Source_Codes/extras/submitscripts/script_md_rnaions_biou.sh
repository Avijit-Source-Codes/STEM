#! /bin/bash
# Written by Ryan Hayes 2010-08-20 to test the recompiled version of gromacs.

# export OMP_NUM_THREADS=8
# mpiexec -n $NODES ./md_rnaions.cex
# mpiexec -bynode -n $NODES -x OMP_NUM_THREADS=8 ./md_rnaions.cex
# mpiexec -bynode -n $NODES -x OMP_NUM_THREADS=1 ./md_rnaions.cex
# mpiexec -n 1 ./md_rnaions.cex
# mpiexec -bynode -n 1 -x OMP_NUM_THREADS=1 ./md_rnaions.cex

# OMP_NUM_THREADS=32
# XLSMPOPTS="startproc=0:stride=4"
# mpiexec -bynode -n $NODES -x OMP_NUM_THREADS=32 -x XLSMPOPTS=startproc=0:stride=4 ./md_rnaions.cex $INPUT
# mpiexec -bynode -n $NODES -x OMP_NUM_THREADS=1 ./md_rnaions.cex
mpiexec -bynode -n $NODES -x OMP_NUM_THREADS=32 -x XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=4 ./md_rnaions.cex $INPUT
