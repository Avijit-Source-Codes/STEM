#@ job_name = gmx0
#@ comment = "tt1"
#@ error = $(job_name).$(bg_size).err
#@ output = $(job_name).$(bg_size).out
#@ environment = COPY_ALL
#@ wall_clock_limit = 24:00:00
#@ notification = error
#@ job_type = bluegene
#@ class = compute
#@ bg_size = 32  
#@ queue

# --ranks-per-node is the number of processes per node
# --np is the total number of processes for the job

DIR=`pwd`
EXE=$DIR/md_rnaions.cex
# ARGS=$DIR/input/PK54_1.mdp
ARGS=$DIR/input/2GIS_nS_BGQ.mdp

#### for more than one args, use ARG1, ARG2, ARG3,...

#### --np 512
# /bgsys/drivers/ppcfloor/bin/runjob --np 16 --ranks-per-node=16 --envs OMP_NUM_THREADS=1 --exe $EXE --args $ARGS 
/bgsys/drivers/ppcfloor/bin/runjob --np 32 --ranks-per-node=1 --envs XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=1 --envs OMP_NUM_THREADS=64 --exe $EXE --args $ARGS 


#### notes:
#### in order to submit jobs, first creat a sub-directory at the /bgqscratch/, for example, at the /bgqscratch, type "mkdir $USERID"

#### for more than one args, use "--args $ARG1, --args $ARG2, --args $ARG3,...
#### the minimum value of "bg_size" is 32
#### the value of "np" can be adjustable, but no more than bg_size x 16
#### to see more options of "runjob", type "runjob --help"

#### See section 5.3.4 for OMP parallelization on BGQ
#### http://www.epcc.ed.ac.uk/facilities/dirac/userguide/batch

#### # Set the BG options for the job
#### export BG_THREADLAYOUT=1
#### export BG_SHAREDMEMSIZE=32
#### export BG_ALLOW_CACHELINE_LOCKING=1
#### export BG_L2LOCK_L1_ONLY=1
#### export L1P_POLICY=std
#### 
#### # Shift to the directory the job was submitted from
#### cd $PBS_O_WORKDIR
#### 
#### # Set the number of parallel tasks
#### export PTASKS=1
#### export PTASKS_PER_NODE=1
#### export OMP_NUM_THREADS=16
#### 
#### # Run the job on the correct block
#### /bgsys/drivers/ppcfloor/hlcs/bin/runjob --block $PBS_QUEUE -n $PTASKS -p $PTASKS_PER_NODE --env_all --exe ./hello_omp.x

#### --np and -n are the same. Maybe --ranks-per-node and -p are the same?


