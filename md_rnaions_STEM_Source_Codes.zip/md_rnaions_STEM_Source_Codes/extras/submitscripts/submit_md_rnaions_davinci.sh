#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module remove GCC/4.4.7
module load intel/2015.02
module load OpenMPI/1.8.6

################## dvainci.rice.edu ####################
ACCOUNT="--account=ctbp-onuchic"
QUEUE=ctbp-onuchic
export PPN=16

# ACCOUNT=""
# QUEUE=serial
# export PPN=12
################## dvainci.rice.edu ####################


export EDIR=`pwd`/../md_rnaions/src

JOBNAME=script_md_rnaions
export NODES=1
# Walltime in seconds
WALLTIME=86400
# Walltime in minutes
WALLTIME_M=`awk 'BEGIN {print '$WALLTIME'/60}'`

WORKDIR=`pwd`

SCRIPT=script_md_rnaions_davinci.sh
export INPUT=polyU_ana.mdp
QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE $ACCOUNT --nodes=$NODES --ntasks-per-node=$PPN --time=$WALLTIME_M --workdir=$WORKDIR --export=ALL"
JOBID=`sbatch $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`
