#! /bin/bash -l

module load xl
module load mpi/xl

llsubmit ./script_md_rnaions_BGQ3.sh
