#@ job_name = md_rnaions
#@ comment = "tt1"
#@ error = $(job_name).$(step_name).err
#@ output = $(job_name).$(step_name).out
#@ environment = COPY_ALL
#@ wall_clock_limit = 24:00:00
#@ notification = error
#@ job_type = bluegene
#@ class = compute
#@ bg_size = 32

#@ step_name = equil
#@ queue

#@ step_name = step1
#@ dependency = (equil >= 0)
#@ queue

#@ step_name = step2
#@ dependency = (step1 >= 0)
#@ queue

#@ step_name = step3
#@ dependency = (step2 >= 0)
#@ queue

#@ step_name = step4
#@ dependency = (step3 >= 0)
#@ queue


# --ranks-per-node is the number of processes per node
# --np is the total number of processes for the job

SYS=2GIS_glass

DIR=`pwd`
EXE=$DIR/md_rnaions.cex

#### for more than one args, use ARG1, ARG2, ARG3,...

if [[ $LOADL_STEP_NAME == "equil" ]]
then

#### --np 512
ARGS=$DIR/input/${SYS}1.mdp
echo "Starting $ARGS at `date`" > outfiles/log0
/bgsys/drivers/ppcfloor/bin/runjob --np 32 --ranks-per-node=1 --envs XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=1 --envs OMP_NUM_THREADS=64 --exe $EXE --args $ARGS 

ls -l outfiles > outfiles_snapshot0

ARGS=$DIR/input/${SYS}2.mdp
echo "Starting $ARGS at `date`" > outfiles/log1
/bgsys/drivers/ppcfloor/bin/runjob --np 32 --ranks-per-node=1 --envs XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=1 --envs OMP_NUM_THREADS=64 --exe $EXE --args $ARGS 

ls -l outfiles > outfiles_snapshot1

ARGS=$DIR/input/${SYS}3.mdp
echo "Starting $ARGS at `date`" > outfiles/log2
/bgsys/drivers/ppcfloor/bin/runjob --np 32 --ranks-per-node=1 --envs XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=1 --envs OMP_NUM_THREADS=64 --exe $EXE --args $ARGS 

fi

ARGS=$DIR/input/${SYS}4.mdp
echo "Starting $ARGS at `date`" > outfiles/log3
/bgsys/drivers/ppcfloor/bin/runjob --np 32 --ranks-per-node=1 --envs XLSMPOPTS=SPINS=0:YIELDS=0:STACK=8000000:STARTPROC=0:stride=1 --envs OMP_NUM_THREADS=64 --exe $EXE --args $ARGS 


#### notes:
#### in order to submit jobs, first creat a sub-directory at the /bgqscratch/, for example, at the /bgqscratch, type "mkdir $USERID"

#### for more than one args, use "--args $ARG1, --args $ARG2, --args $ARG3,...
#### the minimum value of "bg_size" is 32
#### the value of "np" can be adjustable, but no more than bg_size x 16
#### to see more options of "runjob", type "runjob --help"

#### See section 5.3.4 for OMP parallelization on BGQ
#### http://www.epcc.ed.ac.uk/facilities/dirac/userguide/batch

#### # Set the BG options for the job
#### export BG_THREADLAYOUT=1
#### export BG_SHAREDMEMSIZE=32
#### export BG_ALLOW_CACHELINE_LOCKING=1
#### export BG_L2LOCK_L1_ONLY=1
#### export L1P_POLICY=std
#### 
#### # Shift to the directory the job was submitted from
#### cd $PBS_O_WORKDIR
#### 
#### # Set the number of parallel tasks
#### export PTASKS=1
#### export PTASKS_PER_NODE=1
#### export OMP_NUM_THREADS=16
#### 
#### # Run the job on the correct block
#### /bgsys/drivers/ppcfloor/hlcs/bin/runjob --block $PBS_QUEUE -n $PTASKS -p $PTASKS_PER_NODE --env_all --exe ./hello_omp.x

#### --np and -n are the same. Maybe --ranks-per-node and -p are the same?


