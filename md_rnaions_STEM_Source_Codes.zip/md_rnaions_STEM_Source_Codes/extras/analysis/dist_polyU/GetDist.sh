#! /bin/bash -l
# Written by Ryan Hayes 2015-06-19 to get distance distributions

module load intel/2013.1.039
module load openmpi/1.6.5-intel

GD=/home/rlh6/Programs/gromacs-4.6.5/float/bin

DDIR=../../outfiles
RDIR=Results
mkdir $RDIR

TOP=../../polyU_ana_pl2.top
MGTOP=MgTop.top

# O5' of res 1 and O3' of res 80
NDX=$RDIR/dist.ndx
echo "[ R1 ]" > $NDX
echo "1" >> $NDX
echo "[ R80 ]" >> $NDX
echo "797" >> $NDX

MDP=$RDIR/quick.mdp
echo "pbc = xyz" > $MDP

awk '{
  if ($1=="[") {
    DIRECTIVE=$2;
  }
  if (DIRECTIVE=="atomtypes") {
    if (substr($1,1,1)!="[" && substr($1,1,1)!=";") {
      if (PRINTEDMG==0) {
        print " MG     1.000    0.000 A    0.000   0.596046448E-09";
        PRINTEDMG=1;
      }
    }
  }
  if ($2=="system") {
    print "#include \"Mg.itp\"";
    print "";
  } 
  print $0;
} END {print "MG 3000"}' $TOP > $MGTOP

for i in `awk 'BEGIN {for (i=0; i<10; i++) {print i}}'`
do

j=0

TPR=$RDIR/quick.$i.tpr
GRO=$DDIR/confin.$i.$j.gro
XTC=$DDIR/traj.$i.$j.xtc
DIST=$RDIR/dist.$i.xvg

$GD/grompp -f $MDP -p $TOP -c $GRO -o $TPR
$GD/grompp -f $MDP -p $MGTOP -c $GRO -o $TPR

echo -e "0\n1\n" | $GD/g_dist -f $XTC -s $TPR -n $NDX -o $DIST -xvg none # -b 10000

rm \#*
rm Results/\#*

done

