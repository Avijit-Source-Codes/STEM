#! /bin/bash

# Not sure if this is a good idea, probably not. I'm averaging the fret efficiency before solving for R

RDIR=Results

R0=5.5

for i in `awk 'BEGIN {for (i=0; i<32; i++) {print i}}'`
do

DIST=$RDIR/dist.$i.xvg
MEANE=$RDIR/meanE.$i.xvg

awk 'BEGIN {R0='$R0'} {if (NF==5) {R=$2/R0; R3=R*R*R; SUM+=(1/(1+R3*R3)); COUNT++}} END {print SUM/COUNT}' $DIST > $MEANE

done
