#! /bin/bash

RDIR=Results

for i in `awk 'BEGIN {for (i=0; i<32; i++) {print i}}'`
do

DIST=$RDIR/dist.$i.xvg
MEAN=$RDIR/mean.$i.xvg

awk '{if (NF==5) {SUM+=$2; COUNT++}} END {print SUM/COUNT}' $DIST > $MEAN

done
