#! /bin/bash -l
# Written by Ryan Hayes 2015-01-12 to run WHAM

# module load jdk/1.7.0_60
# JAVA=java

JAVA=/apps/java/jdk1.8.0_45/bin/java

WDIR=/home/rlh6/Programs

# java [-Xmx1000m] -jar WHAM.jar --config configurationFile
$JAVA -jar $WDIR/WHAM.1.06.jar --config WHAM.config
