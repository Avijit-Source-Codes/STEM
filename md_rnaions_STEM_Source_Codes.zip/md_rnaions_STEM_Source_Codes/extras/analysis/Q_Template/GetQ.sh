#! /bin/bash -l
# Written by Ryan Hayes 2015-01-12 to do WHAM on Q.

Ts=(109 112 115 118 121 122.5 124 128)

awk '{print $1,$2,(2*$5/$4)**(1.0/6.0)}' cmaptop.dat > cmap.dat

awk '{if ($1>=56 && $1<=164 && $2>=290 && $2<=395) {print $1,$2,(2*$5/$4)**(1.0/6.0)}}' cmaptop.dat > cmapH1.dat

for i in `awk 'BEGIN{for (i=0; i<'${#Ts[@]}'; i++) {print i}}'`
do

echo ${Ts[$i]}

PDIR=`pwd`
DDIR=`pwd`/outfiles
SYS=PK4b

CMAP=$PDIR/cmapH1.dat
XTC=$DDIR/traj.$i.0.xtc
NRG=$DDIR/Gt.$i.0.dat
QOUT=$DDIR/Q.$i.out
WIN=$DDIR/WHAM.$i.in

Q/src/getQ $XTC $CMAP $QOUT

awk '{if (FILENAME=="'$NRG'") {E[NR]=$1; NR0=NR} else if ((NR-NR0) > 100) {print E[NR-NR0],$2}}' $NRG $QOUT > $WIN

done

