#! /bin/bash -l

make clean

OPTLEVEL="-O3"
# OPTLEVEL="-g -O0"

CC="gcc"
# CFLAGS="-DNOMPI -fopenmp $OPTLEVEL"
CFLAGS="$OPTLEVEL"
LDLIBS="-lm"
# LDFLAGS="-fopenmp"
  
export CC CFLAGS LDLIBS

make
