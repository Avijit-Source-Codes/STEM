// Written to read xtc files and make them suck less for watching

#include "xdr/xdrfile.h"
#include "xdr/xdrfile_xtc.h"

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define MAXLENGTH 1024

typedef float real;

typedef struct struct_contact{
  int i;
  int j;
  real r0;
} struct_contact;


real mindist(rvec dx,rvec x1,rvec x2,rvec box)
{
  int i;
  for (i=0; i<3; i++) {
    dx[i]=x1[i]-x2[i];
    dx[i]-=box[i]*floor(dx[i]/box[i]+0.5);
  }
  return sqrt(dx[0]*dx[0]+dx[1]*dx[1]+dx[2]*dx[2]);
}


int readcontacts(char* fnm,struct_contact* cmap,int bread)
{
  FILE *fp;
  char line[MAXLENGTH];
  int N=0;
  int i,j;
  real r0;

  fp=fopen(fnm,"r");

  while (fgets(line,MAXLENGTH,fp) != NULL) {
    if (sscanf(line,"%d %d %g",&i,&j,&r0)==3) {
      if (bread) {
        cmap[N].i=i-1;
        cmap[N].j=j-1;
        cmap[N].r0=r0;
      }
      N++;
    }
  }

  fclose(fp);

  return N;
}


void main(int argc, char *argv[])
{
  char *fnm_in, *fnm_cmap, *fnm_out;
  XDRFILE *fp_in;
  int NC;
  struct_contact *cmap;
  FILE *fp_out;

  int N;
  int step;
  real time;
  matrix box;
  rvec xyz;
  rvec *x;
  real prec;

  int i;
  rvec dx;
  int Q;
  
  fnm_in=argv[1];
  fnm_cmap=argv[2];
  fnm_out=argv[3];

  fp_in=xdrfile_open(fnm_in,"r");

  NC=readcontacts(fnm_cmap,NULL,0);
  fprintf(stderr,"Found %d contacts\n",NC);
  cmap=calloc(NC,sizeof(struct_contact));
  readcontacts(fnm_cmap,cmap,1);

  fp_out=fopen(fnm_out,"w");

  /* This function returns the number of atoms in the xtc file in *natoms */
  // extern int read_xtc_natoms(char *fn,int *natoms);
  read_xtc_natoms(fnm_in,&N);

  x=calloc(N,sizeof(rvec));

  /* Read one frame of an open xtc file */
  // extern int read_xtc(XDRFILE *xd,int natoms,int *step,float *time,
  //                     matrix box,rvec *x,float *prec);
  // (usually prec=1000.0)
  while (read_xtc(fp_in,N,&step,&time,box,x,&prec) == exdrOK) {

    Q=0;
    for (i=0; i<3; i++) {
      xyz[i]=box[i][i];
    }

    for (i=0; i<NC; i++) {
      if (mindist(dx,x[cmap[i].i],x[cmap[i].j],xyz)<cmap[i].r0*1.5) {
        Q++;
      }
    }

    fprintf(fp_out,"%g %d\n",time,Q);
  }

  xdrfile_close(fp_in);
  close(fp_out);

  exit(0);
}
