#! /bin/bash

awk 'BEGIN {START=0}
{
  if (START==0) {
    VAL1=$1;
    VAL2=$2;
    START=1;
  } else {
    if ($1>VAL1) {
      VAL1=$1;
    }
    if ($2>VAL2) {
      VAL2=$2;
    }
  }
} END {print VAL1,VAL2}' $1
#! /bin/bash

awk 'BEGIN {START=0}
{
  if (START==0) {
    VAL1=$1;
    VAL2=$2;
    START=1;
  } else {
    if ($1<VAL1) {
      VAL1=$1;
    }
    if ($2<VAL2) {
      VAL2=$2;
    }
  }
} END {print VAL1,VAL2}' $1
