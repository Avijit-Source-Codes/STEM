#! /bin/bash

./GetGamma.cex -s ../../../PRLphysBPS4_conc/274/outfiles/traj.0.0.gro -f ../../../PRLphysBPS4_conc/274/outfiles/traj.0.0.gro -o output -avg average -rc1 0.3 -rc2 4.5 -freq 1000
