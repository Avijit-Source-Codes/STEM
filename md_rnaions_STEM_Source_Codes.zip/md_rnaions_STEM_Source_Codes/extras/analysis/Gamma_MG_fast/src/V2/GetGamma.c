#define MAXLENGTH 4096
#define DIM3 3
#define MOLAR 0.6022

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct
{
  int N;
  double *x;
  double box[DIM3];
  int frame;
} struct_state;

typedef struct
{
  double rc1; // inner cutoff
  double rc2; // outer cutoff
  int bins; // number of bins on each size of cubic grid in volume calculation
  int freq; // frequency to sample frames
  char coord_fnm[MAXLENGTH];
  char traj_fnm[MAXLENGTH];
  char out_fnm[MAXLENGTH];
  char avg_fnm[MAXLENGTH];
  FILE *coord;
  FILE *traj;
  FILE *out;
  FILE *avg;
  int N_ALL;
  int N_RNA;
  int N_MG;
  int N_0;
  struct_state *state;
} struct_calc;


void readgronumber(struct_calc *calc,FILE *coord)
{
  int i;
  char line[MAXLENGTH];
  char token[MAXLENGTH];

  fgets(line,MAXLENGTH,coord);
  fgets(line,MAXLENGTH,coord);
  sscanf(line,"%d",&(calc->N_ALL));
  for (i=0; i<calc->N_ALL; i++) {
    fgets(line,MAXLENGTH,coord);
    sscanf(line+5,"%s",token);
    if (strcmp("MG",token)==0) {
      break;
    }
  }

  if (i<calc->N_ALL) {
    calc->N_RNA=i;
    calc->N_MG=calc->N_ALL-calc->N_RNA;
    calc->N_0=0;
  } else {
    fprintf(stderr,"Error, no MG found in coord file\n");
    exit(0);
  }
}


struct_state* alloc_state(int N)
{
  struct_state *state;

  state=malloc(sizeof(struct_state));

  state->frame=-1;
  state->x=calloc(sizeof(double),DIM3*N);

  return state;
}


void free_state(struct_state *state)
{
  free(state->x);
  free(state);
}


struct_calc* alloc_calc(int argc, char *argv[])
{
  int i;
  struct_calc *calc;

  calc=malloc(sizeof(struct_calc));

  // default values
  calc->rc1=0.3;
  calc->rc2=4.5;
  calc->bins=25;
  calc->freq=1;

  for (i=1; i<argc; i++) {
    if (strcmp(argv[i],"-rc1")==0) {
      i++;
      sscanf(argv[i],"%lf",&(calc->rc1));
    } else if (strcmp(argv[i],"-rc2")==0) {
      i++;
      sscanf(argv[i],"%lf",&(calc->rc2));
    } else if (strcmp(argv[i],"-s")==0) {
      i++;
      strcpy(calc->coord_fnm,argv[i]);
    } else if (strcmp(argv[i],"-f")==0) {
      i++;
      strcpy(calc->traj_fnm,argv[i]);
    } else if (strcmp(argv[i],"-o")==0) {
      i++;
      strcpy(calc->out_fnm,argv[i]);
    } else if (strcmp(argv[i],"-avg")==0) {
      i++;
      strcpy(calc->avg_fnm,argv[i]);
    } else if (strcmp(argv[i],"-bins")==0) {
      i++;
      sscanf(argv[i],"%d",&(calc->bins));
    } else if (strcmp(argv[i],"-freq")==0) {
      i++;
      sscanf(argv[i],"%d",&(calc->freq));
    } else if (strcmp(argv[i],"-help")==0) {
      fprintf(stderr,
        "Calculated the excess MG near RNA. Currently is hardcoded to treat all"
        "atoms before first MG as RNA and all atoms afterward as MG. Options"
        "are:"
        "  -help           print this help message"
        "  -s      <file>  input coordinate in .gro format"
        "  -f      <file>  trajectory in .gro format"
        "  -o      <file>  instantaneous output file"
        "  -avg    <file>  time averaged output file"
        "  -rc1    <float> distance in nm that Mg cannot penetrate. This volume"
        "                  is subtracted from the calculation"
        "  -rc2    <float> distance in nm used as a cutoff for calculating"
        "                  excess Mg. All Mg within this distance are counted"
        "                  and the number of Mg expected to occupy the"
        "                  difference in volumes between the rc1 and rc2"
        "                  regions is subtracted to give the excess Mg"
        "  -bins   <int>   bins x bins x bins cubic grid for volume calculation"
        "  -freq   <int>   Only every \"freq\" frame will be analyzed");
      exit(0);
    }
  }

  calc->coord=fopen(calc->coord_fnm,"r");
  if (calc->coord==NULL) {
    fprintf(stderr,"coord file %s could not be opened\n",calc->coord_fnm);
    exit(0);
  }
  readgronumber(calc,calc->coord);
  fclose(calc->coord);

  calc->traj=fopen(calc->traj_fnm,"r");
  if (calc->traj==NULL) {
    fprintf(stderr,"traj file %s could not be opened\n",calc->traj_fnm);
    exit(0);
  }

  calc->out=fopen(calc->out_fnm,"w");
  if (calc->out==NULL) {
    fprintf(stderr,"out file %s could not be opened\n",calc->out_fnm);
    exit(0);
  }

  calc->avg=fopen(calc->avg_fnm,"w");
  if (calc->avg==NULL) {
    fprintf(stderr,"avg file %s could not be opened\n",calc->avg_fnm);
    exit(0);
  }

  calc->state=alloc_state(calc->N_ALL);

  return calc;
}


void free_calc(struct_calc *calc)
{
  fclose(calc->traj);
  fclose(calc->out);
  fclose(calc->avg);
  free_state(calc->state);
  free(calc);
}


int readgro(struct_calc *calc,FILE *traj)
{
  char *retval;
  int i;
  double *x=calc->state->x;
  double *box=calc->state->box;
  char line[MAXLENGTH];

  fgets(line,MAXLENGTH,traj);
  retval=fgets(line,MAXLENGTH,traj);
  if (retval==NULL) {
    return (retval != NULL);
  }
  sscanf(line,"%d",&(calc->state->N));
  if (calc->N_ALL != calc->state->N) {
    fprintf(stderr,"Error: different number of atoms in coordinate file and trajectory file\n");
    exit(0);
  }
  for (i=0; i<calc->state->N; i++) {
    fgets(line,MAXLENGTH,traj);
    sscanf(line+20,"%lf %lf %lf",x+DIM3*i,x+DIM3*i+1,x+DIM3*i+2);
  }
  retval=fgets(line,MAXLENGTH,traj);
  sscanf(line,"%lf %lf %lf",box,box+1,box+2);

  calc->state->frame++;

  return (retval != NULL);
}


double dist2(double *a,double *b)
{
  int i;
  double dx;
  double dx2=0;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    dx2+=dx*dx;
  }
  return dx2;
}


double dist2_pbc(double *a,double *b,double *box)
{
  int i;
  double dx;
  double dx2=0;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    dx-=box[i]*floor(dx/box[i]+0.5);
    dx2+=dx*dx;
  }
  return dx2;
}


// Move a close to b
double imagevec(double *a,double *b,double *box)
{
  int i,dx;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    a[i]-=box[i]*floor(dx/box[i]+0.5);
  }
}


void copyvec(double *a,double *b)
{
  int i;
  for (i=0; i<DIM3; i++) {
    a[i]=b[i];
  }
}


void minvec(double *min,double *a)
{
  int i;
  for (i=0; i<DIM3; i++) {
    if (a[i]<min[i]) {
      min[i]=a[i];
    }
  }
}


void maxvec(double *max,double *a)
{
  int i;
  for (i=0; i<DIM3; i++) {
    if (a[i]>max[i]) {
      max[i]=a[i];
    }
  }
}


int getnumber(struct_calc *calc)
{
  int i,j;
  int r2=calc->rc2*calc->rc2;
  double *x=calc->state->x;
  double *box=calc->state->box;
  int n=0;

  for (i=calc->N_RNA; i<calc->N_ALL; i++) {
    for (j=calc->N_0; j<calc->N_RNA; j++) {
      if (dist2_pbc(x+DIM3*i,x+DIM3*j,box)<=r2) {
        n++;
        break;
      }
    }
  }
  return n;
}


double rectify(struct_calc *calc)
{
  int i;
  double *x=calc->state->x;
  double *box=calc->state->box;

  for (i=calc->N_0+1; i<calc->N_RNA; i++) {
    imagevec(x+DIM3*i,x+DIM3*(i-1),box);
  }
}


double getvolume(struct_calc *calc,double rc)
{
  int n=0;
  int i,j,k,l;
  double r2=rc*rc;
  double *x=calc->state->x;
  int bins=calc->bins;
  double min[DIM3], max[DIM3], point[DIM3], dx[DIM3];

  copyvec(min,x+calc->N_0);
  copyvec(max,x+calc->N_0);
  for (i=calc->N_0+1; i<calc->N_RNA; i++) {
    minvec(min,x+DIM3*i);
    maxvec(max,x+DIM3*i);
  }

  for (i=0; i<DIM3; i++) {
    min[i]-=rc;
    max[i]+=rc;
    dx[i]=(max[i]-min[i])/bins;
  }
  // fprintf(stderr,"rc=%f\n",rc); // DEBUG
  // fprintf(stderr,"dx=%f %f %f\n",dx[0],dx[1],dx[2]); // DEBUG

  for (i=0; i<bins; i++) {
    point[0]=min[0]+(i+0.5)*dx[0];
    for (j=0; j<bins; j++) {
      point[1]=min[1]+(j+0.5)*dx[1];
      for (k=0; k<bins; k++) {
        point[2]=min[2]+(k+0.5)*dx[2];
        for (l=calc->N_0; l<calc->N_RNA; l++) {
          if (dist2(point,x+DIM3*l)<=r2) {
            // fprintf(stderr,"point %d %d %d, atom %d, dist2 %f\n",i,j,k,l,dist2(point,x+DIM3*l)); // DEBUG
            n++;
            break;
          }
        }
      }
    }
  }

  // fprintf(stderr,"%d voxels\n",n); // DEBUG
  return dx[0]*dx[1]*dx[2]*n;
}


void calc_avg(struct_calc *calc)
{
  char line[MAXLENGTH];
  double data[5];
  double sum[5];
  double N=0;
  int i;

  fclose(calc->out);
  calc->out=fopen(calc->out_fnm,"r");
  
  while (fgets(line,MAXLENGTH,calc->out) != NULL) {
    sscanf(line,"%lg %lg %lg %lg %lg",data,data+1,data+2,data+3,data+4);
    for (i=0; i<5; i++) {
      sum[i]+=data[i];
    }
    N++;
  }

  for (i=0; i<5; i++) {
    sum[i]/=N;
  }

  fprintf(calc->avg,"%g %g %g %g %g\n",sum[0],sum[1],sum[2],sum[3],sum[4]);
}


int main(int argc, char *argv[])
{
  struct_calc *calc;
  double n,v1,v2,v3,c,g;

  calc=alloc_calc(argc,argv);

  fprintf(stderr,"Output format:\nNumber  Volume1  Volume2  Conc[M]  Gamma\n");
  while (readgro(calc,calc->traj)) {
    if (calc->state->frame % calc->freq == 0) {
      fprintf(stderr,"Frame %d\n",calc->state->frame);

      // Calculate number of Mg
      n=(double) getnumber(calc);

      // Calculate volume
      rectify(calc);
      v1=getvolume(calc,calc->rc1);
      v2=getvolume(calc,calc->rc2);
      v3=calc->state->box[0]*calc->state->box[1]*calc->state->box[2];

      // Calculate Gamma
      c=(calc->N_MG-n)/(v3-v2);
      g=n-c*(v2-v1);
      fprintf(calc->out,"%g %g %g %g %g\n",n,v1,v2,c/MOLAR,g);
    }
  }
  
  calc_avg(calc);

  free_calc(calc);

  return 0;
}
