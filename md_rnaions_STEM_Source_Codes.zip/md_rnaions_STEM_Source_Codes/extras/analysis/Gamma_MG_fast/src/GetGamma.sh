#! /bin/bash

./Compile.sh
mkdir Gamma

Ls=(274 93 74 65 59 55 52)

for i in `awk 'BEGIN {for (i=0; i<'${#Ls[@]}'; i++) {print i}}'`
do

  L=${Ls[$i]}
  SYS=PK_side${L}


  DATDIR=../../PRLphysBPS4_conc/$L/outfiles
  GRO=$DATDIR/traj.0.0.gro

  OUT=Gamma/${SYS}.out
  AVG=Gamma/${SYS}.avg

  ./GetGamma.cex -f $GRO -o $OUT -avg $AVG -rc1 0.3 -rc2 4.5 -freq 100

done
