#! /bin/bash

./GetGamma.cex -f ../../../PRLphysBPS4_conc/274/outfiles/traj.0.0.gro -rc1 0.3 -rc2 4.5 -freq 1000
