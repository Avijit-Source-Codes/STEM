#define MAXLENGTH 4096
#define DIM3 3
#define MOLAR 0.6022

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct
{
  int N;
  double *x;
  double box[DIM3];
  int frame;
} struct_state;

typedef struct
{
  double rc1; // inner cutoff
  double rc2; // outer cutoff
  int freq; // frequency to sample frames
  char coord_fnm[MAXLENGTH];
  char traj_fnm[MAXLENGTH];
  FILE *traj;
  struct_state *state;
} struct_calc;


struct_state* alloc_state()
{
  struct_state *state;

  state=malloc(sizeof(struct_state));

  state->frame=-1;
  state->x=calloc(sizeof(double),DIM3*864); // PARM

  return state;
}


void free_state(struct_state *state)
{
  free(state->x);
  free(state);
}


struct_calc* alloc_calc(int argc, char *argv[])
{
  int i;
  struct_calc *calc;

  calc=malloc(sizeof(struct_calc));

  for (i=1; i<argc; i++) {
    if (strcmp(argv[i],"-rc1")==0) {
      i++;
      sscanf(argv[i],"%lf",&(calc->rc1));
    } else if (strcmp(argv[i],"-rc2")==0) {
      i++;
      sscanf(argv[i],"%lf",&(calc->rc2));
    } else if (strcmp(argv[i],"-s")==0) {
      i++;
      strcpy(calc->coord_fnm,argv[i]);
    } else if (strcmp(argv[i],"-f")==0) {
      i++;
      strcpy(calc->traj_fnm,argv[i]);
      calc->traj=fopen(calc->traj_fnm,"r");
    } else if (strcmp(argv[i],"-freq")==0) {
      i++;
      sscanf(argv[i],"%d",&(calc->freq));
    }
  }

  calc->state=alloc_state();

  return calc;
}


void free_calc(struct_calc *calc)
{
  fclose(calc->traj);
  free_state(calc->state);
  free(calc);
}


int readgro(struct_calc *calc,FILE *traj)
{
  char *retval;
  int i;
  double *x=calc->state->x;
  double *box=calc->state->box;
  char line[MAXLENGTH];

  fgets(line,MAXLENGTH,traj);
  fgets(line,MAXLENGTH,traj);
  sscanf(line,"%d",&(calc->state->N));
  for (i=0; i<calc->state->N; i++) {
    fgets(line,MAXLENGTH,traj);
    sscanf(line+20,"%lf %lf %lf",x+DIM3*i,x+DIM3*i+1,x+DIM3*i+2);
  }
  retval=fgets(line,MAXLENGTH,traj);
  sscanf(line,"%lf %lf %lf",box,box+1,box+2);

  calc->state->frame++;

  return (retval != NULL);
}


double dist2(double *a,double *b)
{
  int i;
  double dx;
  double dx2=0;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    dx2+=dx*dx;
  }
  return dx2;
}


double dist2_pbc(double *a,double *b,double *box)
{
  int i;
  double dx;
  double dx2=0;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    dx-=box[i]*floor(dx/box[i]+0.5);
    dx2+=dx*dx;
  }
  return dx2;
}


// Move a close to b
double imagevec(double *a,double *b,double *box)
{
  int i,dx;

  for (i=0; i<DIM3; i++) {
    dx=a[i]-b[i];
    a[i]-=box[i]*floor(dx/box[i]+0.5);
  }
}


void copyvec(double *a,double *b)
{
  int i;
  for (i=0; i<DIM3; i++) {
    a[i]=b[i];
  }
}


void minvec(double *min,double *a)
{
  int i;
  for (i=0; i<DIM3; i++) {
    if (a[i]<min[i]) {
      min[i]=a[i];
    }
  }
}


void maxvec(double *max,double *a)
{
  int i;
  for (i=0; i<DIM3; i++) {
    if (a[i]>max[i]) {
      max[i]=a[i];
    }
  }
}


int getnumber(struct_calc *calc)
{
  int i,j;
  int r2=calc->rc2*calc->rc2;
  double *x=calc->state->x;
  double *box=calc->state->box;
  int n=0;

  for (i=614; i<864; i++) { // PARM
    for (j=0; j<614; j++) { // PARM
      if (dist2_pbc(x+DIM3*i,x+DIM3*j,box)<=r2) {
        n++;
        break;
      }
    }
  }
  return n;
}


double rectify(struct_calc *calc)
{
  int i;
  double *x=calc->state->x;
  double *box=calc->state->box;

  for (i=1; i<614; i++) { // PARM
    imagevec(x+DIM3*i,x+DIM3*(i-1),box);
  }
}


double getvolume(struct_calc *calc,double rc)
{
  int n=0;
  int i,j,k,l;
  double r2=rc*rc;
  double *x=calc->state->x;
  int bins=25; // PARM
  double min[DIM3], max[DIM3], point[DIM3], dx[DIM3];

  copyvec(min,x+0); // PARM
  copyvec(max,x+0); // PARM
  for (i=1; i<614; i++) { // PARM
    minvec(min,x+DIM3*i);
    maxvec(max,x+DIM3*i);
  }

  for (i=0; i<DIM3; i++) {
    min[i]-=rc;
    max[i]+=rc;
    dx[i]=(max[i]-min[i])/bins;
  }
  // fprintf(stderr,"rc=%f\n",rc); // DEBUG
  // fprintf(stderr,"dx=%f %f %f\n",dx[0],dx[1],dx[2]); // DEBUG

  for (i=0; i<bins; i++) {
    point[0]=min[0]+(i+0.5)*dx[0];
    for (j=0; j<bins; j++) {
      point[1]=min[1]+(j+0.5)*dx[1];
      for (k=0; k<bins; k++) {
        point[2]=min[2]+(k+0.5)*dx[2];
        for (l=0; l<614; l++) { // PARM
          if (dist2(point,x+DIM3*l)<=r2) {
            // fprintf(stderr,"point %d %d %d, atom %d, dist2 %f\n",i,j,k,l,dist2(point,x+DIM3*l)); // DEBUG
            n++;
            break;
          }
        }
      }
    }
  }

  // fprintf(stderr,"%d voxels\n",n); // DEBUG
  return dx[0]*dx[1]*dx[2]*n;
}


int main(int argc, char *argv[])
{
  struct_calc *calc;
  double n,v1,v2,v3,c,g;

  calc=alloc_calc(argc,argv);

  while (readgro(calc,calc->traj)) {
    if (calc->state->frame % calc->freq == 0) {
      // Calculate number of Mg
      n=(double) getnumber(calc);

      // Calculate volume
      rectify(calc);
      v1=getvolume(calc,calc->rc1);
      v2=getvolume(calc,calc->rc2);
      v3=calc->state->box[0]*calc->state->box[1]*calc->state->box[2];

      // Calculate Gamma
      c=(250-n)/(v3-v2); // PARM
      g=n-c*(v2-v1);
      fprintf(stderr,"%g %g %g %g %g\n",n,v1,v2,MOLAR*c,g);
    }
  }
  
  free_calc(calc);

  return 0;
}
