#! /bin/bash -l
# Written by Ryan Hayes on 2013-01-26 to get the preferential interaction coefficients.

module load intel/2013.1.039
module load openmpi/1.6.5-intel

GD=/home/rlh6/Programs/gromacs-4.6.5/double/bin

DIR=`pwd`
mkdir $DIR/Number
mkdir $DIR/Volume
mkdir $DIR/Gamma

# 30 A cutoff
CUT=4.5
# cutoff - 1.4 A in nm
PROBE=`awk 'BEGIN {print '$CUT'-0.14}'`
probe=0.16
SMALLBOX=`awk 'BEGIN {print 2*'$CUT'+25}'`

#Ts=(80 84 88 90 92 94 96 98 100 102 104 106 110 114 118)
# Ls=(274 93 74 65 59 55 52)
Ls=(274)
# Vs=(0.01 0.03 0.06 0.10 0.15)

# KCs=(20 40 60 150)
# V=0.15

# for h in `awk 'BEGIN {for (i=0; i<'${#KCs[@]}'; i++) {print i}}'`
# do

for i in `awk 'BEGIN {for (i=0; i<'${#Ls[@]}'; i++) {print i}}'`
do

  #T=${Ts[$i]}
  L=${Ls[$i]}
  # V=${Vs[$i]}
  # KC=${KCs[$h]}
  SYS=PK_side${L}
  # SYS=rRNA58mer_K${KC}_V$V


  DATDIR=../../      #gro file finder eventually
  SDATDIR=../../PRLphysBPS4_conc/$L/outfiles
  #GRO=$DATDIR/traj$T.xtc
  TOPnoMG=$DATDIR/PK4b.top
  GROnoMG=$DATDIR/PK.gro
  GRO=$DATDIR/PK_wMg.gro
  XTC=$SDATDIR/traj.0.0.gro

  # output directories
  NUMDIR=$DIR/Number/$SYS
  VOLDIR=$DIR/Volume/$SYS
  GAMDIR=$DIR/Gamma/$SYS

  # Number output files
  NDXOUT=$NUMDIR/$SYS.ndx
  DIST=$NUMDIR/${SYS}_mindist.xvg
  NFAR=$NUMDIR/${SYS}_gt$CUT.xvg
  NNEAR=$NUMDIR/${SYS}_le$CUT.xvg

  # Volume output files
  TPRnoMG=$VOLDIR/${SYS}_noMG.tpr
  MDPMOD=$VOLDIR/${SYS}_nanX.mdp
  GROMOD=$VOLDIR/${SYS}_nanX.gro
  TOPMOD=$VOLDIR/${SYS}_nanX.top
  TPRMOD=$VOLDIR/${SYS}_nanX.tpr
  XTCMOD=$VOLDIR/${SYS}_smallbox.xtc
  GpRVOL=$VOLDIR/${SYS}_gprvol.xvg
  RNAVOL=$VOLDIR/${SYS}_rnavol.xvg
  GAMMAVOL=$VOLDIR/${SYS}_gammavol.xvg
  BULKVOL=$VOLDIR/${SYS}_bulkvol.xvg

  # Gamma output files
  CONCOUT=$GAMDIR/concentration.xvg
  GAMMAOUT=$GAMDIR/gamma.xvg

  DEL_T=1000   #Analyzes every nth frame. where n = DEL_T.

  mkdir $NUMDIR
  mkdir $VOLDIR
  mkdir $GAMDIR

  # Get index file
  # Make an index of RNA (group 0), All Mg (group 1), RNA and Mg (group 2), and individual MG (group 3 to N+2), grab number of MG as program counts them.
  echo -e "keep 0\na C* N* O* P* S*\nkeep 1\na MG\nsplitat 1\nq\n" > $NUMDIR/input
  NUM_MG=`cat $NUMDIR/input | $GD/make_ndx -nice 0 -f $GRO -o $NDXOUT | grep "atoms with name MG" | cut -d' ' -f 2`

  # Count MG
  echo 0 > $NUMDIR/input
  echo 1 >> $NUMDIR/input
  cat $NUMDIR/input | $GD/g_mindist -f $XTC -n $NDXOUT -ng 1 -od $DIST -on $NNEAR -d $CUT -xvg none -group -dt $DEL_T
  awk '{print $1,'$NUM_MG'-$2}' $NNEAR > $NFAR
  rm $DIST

  # Now compute volume
  awk '{if (NR == 1) {print $0; NATOMSp3=3}
    else if (NR == 2) {print $0; NATOMSp3=$1+3}
    else if (NR < NATOMSp3) {print substr($0,1,10) "    X" substr($0,16)}
    else if (NR == NATOMSp3) {print $0}}' $GRO > $GROMOD
  NUM_SYS=`head -n 2 $GROMOD | tail -n 1`
  NUM_RNA=`awk 'BEGIN {print '$NUM_SYS'-'$NUM_MG'}'`
  echo -e "[ defaults ]\n; nbfunc        comb-rule       gen-pairs       fudgeLJ fudgeQQ\n  1             1               no              1.0     1.0\n" > $TOPMOD
  echo -e "[ atomtypes ]\n;atom type; m (u); q (e); particle type; V(cr); W(cr)\nX 1.000 0.000 A 1.000 1.000\n" >> $TOPMOD
  echo -e "[ moleculetype ]\n; name  nrexcl\nRNA          3\n" >> $TOPMOD
  echo -e "[ atoms ]\n;   nr    type   resnr  residu    atom    cgnr  charge\n     1       X       1    RNA        X       1       0.000\n" >> $TOPMOD
  echo -e "[ moleculetype ]\n; name  nrexcl\nMG           3\n" >> $TOPMOD
  echo -e "[ atoms ]\n;   nr    type   resnr  residu    atom    cgnr  charge\n     1       X       1    MG         X       1       0.000\n" >> $TOPMOD
  echo -e "[ system ]\nFake Top File\n" >> $TOPMOD
  echo -e "[ molecules ]\nRNA $NUM_RNA\nMG $NUM_MG\n" >> $TOPMOD
  echo "" > $MDPMOD

  $GD/grompp -f $MDPMOD -c $GROnoMG -p $TOPnoMG -o $TPRnoMG -po $DIR/junk.mdp -maxwarn 35
  rm $DIR/junk.mdp

  $GD/grompp -f $MDPMOD -c $GROMOD -p $TOPMOD -o $TPRMOD -po $DIR/junk.mdp -maxwarn 35
  rm $DIR/junk.mdp

  echo -e "0\n" > $VOLDIR/input
  cat $VOLDIR/input | $GD/trjconv -s $TPRMOD -f $XTC -o junk.xtc -n $NDXOUT -dt $DEL_T

  echo -e "0\n0\n" > $VOLDIR/input
  cat $VOLDIR/input | $GD/trjconv -s $TPRnoMG -f junk.xtc -o $XTCMOD -n $NDXOUT -pbc whole -center -box $SMALLBOX $SMALLBOX $SMALLBOX -dt $DEL_T
  rm junk.xtc

  echo -e "0\n0\n" > $VOLDIR/input
  cat $VOLDIR/input | $GD/g_sas -s $TPRMOD -f $XTCMOD -tv $RNAVOL -o $DIR/junk.xvg -n $NDXOUT -probe $probe -ndots 576 -xvg none
  rm $DIR/junk.xvg

  echo -e "0\n0\n" > $VOLDIR/input
  cat $VOLDIR/input | $GD/g_sas -s $TPRMOD -f $XTCMOD -tv $GpRVOL -o $DIR/junk.xvg -n $NDXOUT -probe $PROBE -ndots 576 -xvg none
  rm $DIR/junk.xvg

  VOLUME=`awk 'BEGIN {print '$L'*'$L'*'$L'}'`
  #VOLUME=`awk 'BEGIN {ATOMS=0} {if (NR==2) {ATOMS=$1} if (NR==ATOMS+3) {VOLUME=$1*$2*$3} } END {print VOLUME}' $GRO`


  awk '{if (FILENAME=="'$RNAVOL'") {VOLUME[NR]=$2; MAXR=NR} else {print $1 " " $2-VOLUME[NR-MAXR]} }' $RNAVOL $GpRVOL > $GAMMAVOL

  awk '{print $1 " " '$VOLUME'-$2 }' $GpRVOL > $BULKVOL

  # Now compute Gamma
  awk '{if (FILENAME=="'$NFAR'") {NUM[NR]=$2; MAXR=NR} else {print $1 " " NUM[NR-MAXR]/$2/0.6022 } }' $NFAR $BULKVOL > $CONCOUT

  awk '{if (FILENAME=="'$CONCOUT'") {CONC[NR]=$2; MAXRF1=NR} else if (FILENAME=="'$GAMMAVOL'") {NEXP[NR-MAXRF1]=0.6022*CONC[NR-MAXRF1]*$2; MAXRF2=NR} else {print $1 " " $2-NEXP[NR-MAXRF2] } }' $CONCOUT $GAMMAVOL $NNEAR > $GAMMAOUT

done

rm \#* $NUMDIR/\#*
rm \#* $VOLDIR/\#*

