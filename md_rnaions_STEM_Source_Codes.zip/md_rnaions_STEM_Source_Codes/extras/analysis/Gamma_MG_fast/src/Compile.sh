gcc -O3 -lm -o GetGamma.cex GetGamma.c 
