#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void main(int argc, char *argv[])
{
  int XC;
  char fnm[1024];
  FILE *fp;
  int i, j, k, k1, k2;
  char line[1024];
  char *buf;
  int bufn;
  int N, N1, N2;
  double *X;
  // Parameters
  int BS=4; // Number of bootstrap bins
  double EF=0.2; // Equilibration fraction - initial portion of data to ignore
  double mX, mXi, mmX, mmXX;

  sscanf(argv[1],"%d",&XC);

  for (i=0; i<(argc-2); i++) {

    // Count the lines in the file
    fp=fopen(argv[i+2],"r");
    N=0;
    while (fgets(line,1024,fp) != NULL) {
      N++;
    }
    fclose(fp);

    // Allocate memory
    X=calloc(N,sizeof(double));

    // Read the file
    fp=fopen(argv[i+2],"r");
    for (j=0; j<N; j++) {
      fgets(line,1024,fp);
      buf=line;
      for (k=0; k<XC; k++) {
        sscanf(buf,"%lg%n",&(X[j]),&bufn);
        buf+=bufn;
      }
    }
    fclose(fp);

    // Do bootstrap
    mX=0;
    mmX=0;
    mmXX=0;
    N1=(int) (N*EF);
    N2=N;
    for (j=0; j<BS; j++) {
      k1=N1+((N2-N1)*(j+0))/BS;
      k2=N1+((N2-N1)*(j+1))/BS;
      mXi=0;
      for (k=k1; k<k2; k++) {
        mXi+=X[k];
      }
      mX+=mXi;
      mXi/=(k2-k1);
      mmX+=mXi;
      mmXX+=(mXi*mXi);
    }
    mX/=(N2-N1);
    mmX/=BS;
    mmXX/=BS;
    fprintf(stdout,"%g %g\n",mX,sqrt(mmXX-mmX*mmX)/sqrt(BS-1));

    // Free memory
    free(X);
  }
}
