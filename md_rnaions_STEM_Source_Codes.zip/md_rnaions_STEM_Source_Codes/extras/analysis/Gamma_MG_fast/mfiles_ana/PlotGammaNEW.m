% CONC=[
% 5e-6
% 6.4e-6
% 8e-6
% 1e-5
% 1.25e-5
% 1.6e-5
% 2e-5
% 2.5e-5
% 3.2e-5
% 4e-5
% 5e-5
% 6.4e-5
% 8e-5
% 1e-4
% 1.25e-4
% 1.6e-4
% 2e-4
% 2.5e-4
% 3.2e-4
% 4e-4
% 5e-4
% 6.4e-4
% 8e-4
% 1e-3
% 1.2e-3
% 1.4e-3
% 1.6e-3
% 1.8e-3
% 2e-3
% 2.5e-3
% 3e-3
% 3.5e-3
% 4e-3
% 4.5e-3
% 5e-3
% 5.5e-3
% 6e-3
% 6.5e-3
% 7e-3
% 7.5e-3
% 8e-3
% 8.5e-3
% 9e-3
% 9.5e-3
% 1e-2
% 1.1e-2
% 1.2e-2];

% CONC=-5:0.25:-3.5;

% AC=[0.9,5.8,10.2]/1000;
% ACe=[0.7,2.2,1.4]/1000;
% AG=[10.5,18.7,27.2];
% AGe=[0.4,1.3,0.8];

% Pseudo-knot
% Targets=[
% -5.4133  0.226605
% -5.33417  0.248653
% -5.27251  0.286693
% -5.20946  0.32861
% -5.13435  0.365439
% -5.06851  0.406386
% -5.00685  0.465506
% -4.93174  0.528502
% -4.86792  0.58108
% -4.80285  0.668305
% -4.72852  0.741962
% -4.6667  0.838637
% -4.60164  0.945004
% -4.52653  1.04483
% -4.46286  1.13957
% -4.40181  1.25829
% -4.3247  1.37822
% -4.26087  1.51391
% -4.1972  1.65589
% -4.12271  1.79351
% -4.06043  1.95246
% -3.99459  2.12909
% -3.93432  2.28779
% -3.8572  2.46564
% -3.79338  2.62434
% -3.73109  2.80218
% -3.65599  2.97881
% -3.59216  3.15641
% -3.52911  3.32045];
% AC=10.^(Targets(:,1));
% AG=Targets(:,2);

% Adenine Riboswitch
Targets=[
1e-6    0.504
2e-6    0.840
3e-6    1.155
4e-6    1.408
5e-6    1.639
6e-6    1.912
7e-6    2.017
8e-6    2.248
9e-6    2.479
1e-5    2.731
2e-5    4.265
3e-5    5.420
4e-5    6.345
5e-5    7.059
6e-5    7.626
7e-5    8.172
8e-5    8.782
9e-5    9.118
1e-4    9.412
2e-4    12.374
3e-4    13.718
4e-4    14.811
5e-4    15.756
6e-4    16.429
7e-4    17.038
8e-4    17.500
9e-4    17.941
1e-3    18.550];
AC=Targets(:,1);
AG=Targets(:,2);

SAMITargets=[
    0.9e-3    10.5
    5.8e-3    18.7 
    10.2e-3   27.2];

% rRNA 58mer
rRNATargets=[
    0.107e-3    14.1
    0.149e-3    11.0
    0.388e-3    12.1
    0.98e-3     10.4];

% PK - 54 mM KCl
PK54Targets=[
-5.4133  0.226605
-5.33417  0.248653
-5.27251  0.286693
-5.20946  0.32861
-5.13435  0.365439
-5.06851  0.406386
-5.00685  0.465506
-4.93174  0.528502
-4.86792  0.58108
-4.80285  0.668305
-4.72852  0.741962
-4.6667  0.838637
-4.60164  0.945004
-4.52653  1.04483
-4.46286  1.13957
-4.40181  1.25829
-4.3247  1.37822
-4.26087  1.51391
-4.1972  1.65589
-4.12271  1.79351
-4.06043  1.95246
-3.99459  2.12909
-3.93432  2.28779
-3.8572  2.46564
-3.79338  2.62434
-3.73109  2.80218
-3.65599  2.97881
-3.59216  3.15641
-3.52911  3.32045];
PK54Targets(:,1)=10.^PK54Targets(:,1);

PK79Targets=[
-5.34221  0.17182
-5.27715  0.187101
-5.20204  0.21785
-5.12755  0.247854
-5.0645  0.278602
-4.98877  0.323887
-4.91428  0.36824
-4.83716  0.418556
-4.77612  0.476699
-4.69699  0.537451
-4.62188  0.598017
-4.54801  0.67405
-4.48635  0.750083
-4.40846  0.840652
-4.33072  0.934576
-4.26767  1.02347
-4.1938  1.1295
-4.11606  1.25324
-4.04157  1.39078
-3.9779  1.52905
-3.90403  1.68186
-3.82768  1.83318
-3.76262  1.98357
-3.68875  2.15092
-3.61163  2.3192
-3.53652  2.48748];
PK79Targets(:,1)=10.^PK79Targets(:,1);

% SYSs={
%     'ARibo'
%     'PK_54'
%     'PK_79'
%     'rRNA_20'
%     'rRNA_40'
%     'rRNA_60'
%     'rRNA_150'};
% 
% NC=[16,12,12,4,4,4,4];

SYSs={
    'PK_physioT'};

%NC=[16 12 12];
T=[80 84 88 90 92 94 96 98 100 102 104 106 110 114 118];
for h=1:length(SYSs)
    SYS=SYSs{h};
for i=1:length(T) %T(h)
    %CONCstring=num2str(i-1,'%d');
    % DIR=['Gamma/',SYS,'/',SYS,'_C',CONCstring];
    %DIR=[SYS,'/',SYS,'_C',CONCstring];
    DIR=['Gamma/',SYS,num2str(T(i))];
    Gamma{h}{i}=load([DIR,'/gamma.xvg']);
    Concentration{h}{i}=load([DIR,'/concentration.xvg']);

    % Setup error windows
    EqF=0.2; % Equilibration fraction
    EBs=4; % Error Bins
    NE=size(Gamma{h}{i},1);
    Win{h}{i}=round(EqF*NE):NE;
    for j=1:EBs
        Wine{h}{i,j}=round(EqF*(j-1-EBs)*NE+NE):round(EqF*(j-EBs)*NE+NE);
    end

    mG{h}(i)=mean(Gamma{h}{i}(Win{h}{i},2));
    mC{h}(i)=mean(Concentration{h}{i}(Win{h}{i},2));
    for j=1:EBs
        mGs{h}(i,j)=mean(Gamma{h}{i}(Wine{h}{i,j},2));
        mCs{h}(i,j)=mean(Concentration{h}{i}(Wine{h}{i,j},2));
    end
    mGe{h}(i)=std(mGs{h}(i,:))/sqrt(EBs-1);
    mCe{h}(i)=std(mCs{h}(i,:))/sqrt(EBs-1);
    if (i==1)
        mDG{h}(1)=0;
        mDGs{h}(1,1:EBs)=0;
        mDGe{h}(i)=std(mDGs{h}(i,:))/sqrt(EBs-1);
    else
        mDG{h}(i)=mDG{h}(i-1)+(mG{h}(i)+mG{h}(i-1))/2*(log(mC{h}(i))-log(mC{h}(i-1)));
        mDGs{h}(i,:)=mDGs{h}(i-1,:)+(mGs{h}(i,:)+mGs{h}(i-1,:))./2.*(log(mCs{h}(i,:))-log(mCs{h}(i-1,:)));
        mDGe{h}(i)=std(mDGs{h}(i,:))/sqrt(EBs-1);
    end
end
end





try
    close(1)
end
figure(1)
Q=70;
XLIMS=[5e-7 5e-3];
YLIMS=[0 20];
% handle2=semilogxerrorfixwidth(AC,AG,ACe,AGe,1.1,1,'k','.'); % ,'MarkerSize',12)
handle2=semilogx(Targets(:,1),Targets(:,2),'k.');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'m','r','g','c','b','k'};
for h=1
    hold on
    handle1(h)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1,6)+1},'.:'); % ,'MarkerSize',12)
end
hold off
title('Preferential interaction coefficient of Adenine Riboswitch')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
legend([handle1,handle2],'Simulation','Experiment','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(1,'ARibo.fig')
saveas(1,'ARibo.pdf')







try
    close(2)
end
figure(2)
Q=30;
XLIMS=[5e-7 5e-3];
YLIMS=[0 5];
% handle2=semilogxerrorfixwidth(AC,AG,ACe,AGe,1.1,1,'k','.'); % ,'MarkerSize',12)
handle2(1)=semilogx(PK54Targets(:,1),PK54Targets(:,2),'k.');
hold on
% handle2(2)=semilogx(PK79Targets(:,1),PK79Targets(:,2),'r.');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'m','r','g','c','b','k'};
for h=2:3
    hold on
    handle1(h-1)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1-1,6)+1},'.:'); % ,'MarkerSize',12)
end
hold off
title('Preferential interaction coefficient of Pseudoknot Fragments')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
% legend([handle1,handle2],'54 mM KCl Simulation','79 mM KCl Simulation','54 mM KCl Experiment','79 mM KCl Experiment','Location','Best')
legend([handle1,handle2],'54 mM KCl Simulation (Vanilla)','54 mM KCl Simulation (NNL)','54 mM KCl Experiment','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(2,'PK.fig')
saveas(2,'PK.pdf') 
