function [handle1] = semilogxerrorfixwidth( x,y,dx,dy,wdx,wdy,color,varargin )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

HoldState=get(gcf,'NextPlot');

handle1=semilogx(x,y,varargin{:},'Color',color);
hold on
for i=1:length(x)
    semilogx([x(i)-dx(i),x(i)+dx(i)],[y(i),y(i)],color)
    semilogx([x(i),x(i)],[y(i)-dy(i),y(i)+dy(i)],color)
    semilogx([x(i)-dx(i),x(i)-dx(i)],[y(i)-0.5*wdy,y(i)+0.5*wdy],color)
    semilogx([x(i)+dx(i),x(i)+dx(i)],[y(i)-0.5*wdy,y(i)+0.5*wdy],color)
    semilogx([x(i)/sqrt(wdx),x(i)*sqrt(wdx)],[y(i)-dy(i),y(i)-dy(i)],color)
    semilogx([x(i)/sqrt(wdx),x(i)*sqrt(wdx)],[y(i)+dy(i),y(i)+dy(i)],color)
end

if strcmp(HoldState,'add')
    hold off
end

end

