function [handle1] = ploterrorfixwidth( x,y,dx,dy,wdx,wdy,color,varargin )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

HoldState=get(gcf,'NextPlot');

handle1=plot(x,y,varargin{:},'Color',color);
hold on
for i=1:length(x)
    plot([x(i)-dx(i),x(i)+dx(i)],[y(i),y(i)],color)
    plot([x(i),x(i)],[y(i)-dy(i),y(i)+dy(i)],color)
    plot([x(i)-dx(i),x(i)-dx(i)],[y(i)-0.5*wdy,y(i)+0.5*wdy],color)
    plot([x(i)+dx(i),x(i)+dx(i)],[y(i)-0.5*wdy,y(i)+0.5*wdy],color)
    plot([x(i)-0.5*wdx,x(i)+0.5*wdx],[y(i)-dy(i),y(i)-dy(i)],color)
    plot([x(i)-0.5*wdx,x(i)+0.5*wdx],[y(i)+dy(i),y(i)+dy(i)],color)
end

if strcmp(HoldState,'add')
    hold off
end

end

