%Variables you may want to modify
%Temperature
T=[80 84 88 90 92 94 96 98 100 102 104 106 110 114 118];
%System name(s)
SYS={'PK_physioT'};

for i = [1:length(T)]    %Each i will correspond to a temp in the subsequent loop
DIR=['Gamma/',SYS{1},num2str(T(i))];
GAMMA=load([DIR,'/gamma.xvg']);

G_avg=sum(GAMMA(:,2))/length(GAMMA(:,1));
T_GAM(i,:)=[T(i),G_avg];

end


plot(T_GAM(:,1),T_GAM(:,2),'om-'),xlabel('Temp'),ylabel('Gamma 2+'),title('Magnesium condensation')