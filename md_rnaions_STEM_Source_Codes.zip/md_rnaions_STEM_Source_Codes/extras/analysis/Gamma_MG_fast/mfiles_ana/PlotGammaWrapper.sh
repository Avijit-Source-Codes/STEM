#! /bin/bash
# Written by Ryan Hayes on 2012-07-19 as a wrapper for a matlab script on piglet.rice.edu

MATLAB=/Applications/MatlabR2012a/MATLAB_R2012a.app/bin/matlab
MSCRIPT="PlotGamma"

$MATLAB -nodisplay -r "$MSCRIPT,exit"
exit
