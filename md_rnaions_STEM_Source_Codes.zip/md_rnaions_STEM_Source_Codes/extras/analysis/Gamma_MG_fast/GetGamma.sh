#! /bin/bash

GDIR=/home/rlh6/Programs/gromacs-4.6.5/double/bin

gcc -O3 -lm -o GetGamma.cex GetGamma.c 
gcc -O3 -lm -o Bootstrap.cex Bootstrap.c 

SYSs=(ARibo rRNA58mer rRNA58mer rRNA58mer rRNA58mer PK PK PK PK SAMI)
TAGs=("" _20 _40 _60 _150 _54stiff _54flex _79stiff _79flex "")
Ns=(16 4 4 4 4 12 12 12 12 16)

mkdir Gamma

# for s in `awk 'BEGIN {for (i=0; i<'${#SYSs[@]}'; i++) {print i}}'`
for s in 0
do

N=${Ns[$s]}
SYS=${SYSs[$s]}
TAG=${TAGs[$s]}
DATDIR=../$SYS/outfiles$TAG
OUTDIR=Gamma/$SYS$TAG

mkdir $OUTDIR

for i in `awk 'BEGIN {for (i=0; i<'${Ns[$s]}'; i++) {print i}}'`
do

  GROIN=$DATDIR/confin.$i.0.gro
  TRJIN=$DATDIR/traj.$i.0.xtc

  GRO=$OUTDIR/traj.$i.tmp.gro

  echo -e "0\n" | $GDIR/trjconv -s $GROIN -f $TRJIN -o $GRO

  OUT=$OUTDIR/Gamma.$i.out
  AVG=$OUTDIR/Gamma.$i.avg

  ./GetGamma.cex -f $GRO -o $OUT -avg $AVG -rc1 0.3 -rc2 4.5 -freq 100

  rm $OUTDIR/traj.$i.tmp.gro

done

./Bootstrap.cex 4 $OUTDIR/Gamma.*.out > $OUTDIR/c.dat
./Bootstrap.cex 5 $OUTDIR/Gamma.*.out > $OUTDIR/g.dat

done
