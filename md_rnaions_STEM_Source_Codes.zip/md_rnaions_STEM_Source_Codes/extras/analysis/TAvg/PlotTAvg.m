% load eta_t.2.dat
% load eta_t.3.dat
% load theta_t.3.dat
% load theta_cl_t.3.dat
% load eta_cl_t.3.dat
% plot(1:100,theta_t_3,'k',1:100,eta_t_3,'k--',1:100,theta_cl_t_3,'r',1:100,eta_cl_t_3,'r--')
% mean(theta_t_3+eta_t_3-theta_cl_t_3-eta_cl_t_3)

for i=1:8
    tk{i}=load(['theta_t.',num2str(i-1),'.dat']);
    tcl{i}=load(['theta_cl_t.',num2str(i-1),'.dat']);
    ek{i}=load(['eta_t.',num2str(i-1),'.dat']);
    ecl{i}=load(['eta_cl_t.',num2str(i-1),'.dat']);
    figure(i)
    plot(1:100,tk{i},'k',1:100,ek{i},'k--',1:100,tcl{i},'r',1:100,ecl{i},'r--')
    % mean(theta_t_3+eta_t_3-theta_cl_t_3-eta_cl_t_3)
end