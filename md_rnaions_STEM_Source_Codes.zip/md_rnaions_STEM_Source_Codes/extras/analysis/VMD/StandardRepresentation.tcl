# Written by Ryan Hayes on 2011-07-27 to load SAMoMG7sb for making a movie.

set DIR [pwd]
# set SYS "PK"
# set GRO $DIR/$SYS.gro
# set PAIRS $DIR/pairs

# mol new $GRO type {gro} first 0 last -1 step 1 waitfor 1
# mol new $PDB type {pdb} first 0 last -1 step 1 waitfor 1
# mol addfile $XTC type {xtc} first 0 last -1 step 5 waitfor 1 top

mol delrep 0 top

# # Set up Representations
# set SELECT "chain C and noh"
# mol selection $SELECT
# mol color ColorID 8# mol material Opaque
# mol representation Licorice 0.300000 10.000000 10.000000# mol addrep top
# mol representation Tube 0.800000 16.000000
# mol addrep top
# mol representation NewRibbons 0.000000 6.000000 3.000000 0
# mol addrep top

# set SELECT "residue 3 to 7 14 to 18 and noh"
# mol selection $SELECT
# mol color ColorID 0
# mol material Opaque
# mol representation Licorice 0.300000 10.000000 10.000000
# mol addrep top
# mol representation Tube 0.800000 16.000000
# mol addrep top
# mol representation NewRibbons 0.000000 6.000000 3.000000 0
# mol addrep top

# set SELECT "residue 10 to 12 26 to 28 and noh"
# mol selection $SELECT
# mol color ColorID 7
# mol material Opaque
# mol representation Licorice 0.300000 10.000000 10.000000
# mol addrep top
# mol representation Tube 0.800000 16.000000
# mol addrep top
# mol representation NewRibbons 0.000000 6.000000 3.000000 0
# mol addrep top

set SELECT "resid 1 to 9 111 to 119 and noh"
mol selection $SELECT
mol color ColorID 10
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 14 to 43 and noh"
mol selection $SELECT
mol color ColorID 1
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 26 to 29 87 to 90 and noh"
mol selection $SELECT
mol color ColorID 3
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 34 to 36 and noh"
mol selection $SELECT
mol color ColorID 4
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 44 to 82 and noh"
mol selection $SELECT
mol color ColorID 7
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 91 to 107 and noh"
mol selection $SELECT
mol color ColorID 0
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

set SELECT "resid 10 to 13 83 to 86 108 to 110 and noh"
mol selection $SELECT
mol color ColorID 8
mol material Opaque
mol representation Licorice 0.300000 10.000000 10.000000
mol addrep top
mol representation Tube 0.800000 16.000000
mol addrep top
mol representation NewRibbons 0.000000 6.000000 3.000000 0
mol addrep top

# #Plot the bonds
# set fp [open $PAIRS r]
# set N 0
# while {[gets $fp line] != -1} {
#   # echo $line
#   scan $line "%d %d" i_pair($N) j_pair($N)
#   incr N
# }
# close $fp

# for {set i 0} {$i<$N} {incr i} {
#   mol selection "serial $i_pair($i) $j_pair($i)"
#   mol color ColorID 8
#   mol representation DynamicBonds 30.000000 0.300000 6.000000
#   mol addrep top
# }

# Set Orientation
# molinfo top get {center_matrix rotate_matrix scale_matrix global_matrix}
# molinfo top set {center_matrix rotate_matrix scale_matrix global_matrix} {{{1 0 0 -10.4794} {0 1 0 -20.1766} {0 0 1 -34.1188} {0 0 0 1}} {{0.179808 0.983302 -0.0279993 0} {-0.651161 0.0976411 -0.752634 0} {-0.737332 0.153562 0.657844 0} {0 0 0 1}} {{0.0733823 0 0 0} {0 0.0733823 0 0} {0 0 0.0733823 0} {0 0 0 1}} {{1 0 0 0} {0 1 0 0} {0 0 1 0} {0 0 0 1}}}

# Set up view
axes location Off
color Display Background white
display projection Orthographic
display nearclip set 0.010000
# menu rmsdtt off# menu rmsdtt on

# # Set up to make movie
# menu vmdmovie off# menu vmdmovie on

# First, use VMD's make movie with these settings:
# Renderer: tachyon
# Movie settings: trajectory
# Format: JPEG frames
# Working directory:
# /Users/ryahayes/Desktop/MgPaper/Movies/MovieData
# Name of movie SAMI_7mM_600ns
# Rotation angle: 0
# Trajectory step size: 1

# Then run MakeMovie.sh to concatenate the files.
