#! /bin/bash -l
# Written by Ryan Hayes 2015-04-08

module load intel/2013.1.039
module load openmpi/1.6.5-intel

# GROMDIR=/Users/ryanduck/Programs/gromacs-5.0/float/bin
# GROMDIR=/home/rlh6/Programs/gromacs-4.6.5/float/bin
GROMDIR=/home/rlh6/Programs/gromacs-4.5.4.SBM/float/bin
DIR=`pwd`
INDIR=$DIR/../outfiles
OUTDIR=$DIR/Clean

mkdir $OUTDIR

NDX=$OUTDIR/cat.ndx
INTOP=../system/DCA_7/4KQY.top
TOP=$OUTDIR/null.top
MDP=$OUTDIR/null.mdp

awk 'BEGIN {
  print "[ SYS ]";
  for (i=1;i<=3308;i++) {print i;}
  print "[ RNA ]";
  for (i=1;i<=2808; i++) {print i;}
}' > $NDX

# cp $INTOP $TOP
# echo -e "[ moleculetype ]\nMG 3\n[ atoms ]\n     1          Y      1     MG     MG      1"
awk '{
  if ($2=="system") {
    print "[ moleculetype ]";
    print "MG 3";
    print "";
    print "[ atoms ]";
    print "     1          MG     1     MG     MG      1";
    print "";
    print $0;
  } else if ($2 == "atomtypes") {
    print $0;
    print " MG     1.000    0.000 A    0.000   0.596046448E-09";
  } else if (NF==7 && $3==6) {
    ;
  } else {
    print $0;
  }}' $INTOP > $TOP
echo "MG 500" >> $TOP

touch $MDP

for i in 0 1 2 3 4 5
do

  INGRO=$INDIR/traj.$i.0.gro
  GRO=$OUTDIR/sys.$i.gro
  TPR=$OUTDIR/sys.$i.tpr
  XTC=$OUTDIR/traj.$i.xtc

  head -n 3311 $INGRO > $GRO
  $GROMDIR/grompp -f $MDP -c $GRO -p $TOP -o $TPR
  # echo -e "1\n1\n0\n" | $GROMDIR/trjconv -s $TPR -f $INGRO -o $XTC -n $NDX -center -pbc cluster
  echo -e "1\n0\n" | $GROMDIR/trjconv -s $TPR -f $INGRO -o $XTC -n $NDX -center -pbc whole

done

rm $OUTDIR/\#*
rm $DIR/\#*

cp StandardRepresentation.tcl $OUTDIR/
