% CONC=[
% 5e-6
% 6.4e-6
% 8e-6
% 1e-5
% 1.25e-5
% 1.6e-5
% 2e-5
% 2.5e-5
% 3.2e-5
% 4e-5
% 5e-5
% 6.4e-5
% 8e-5
% 1e-4
% 1.25e-4
% 1.6e-4
% 2e-4
% 2.5e-4
% 3.2e-4
% 4e-4
% 5e-4
% 6.4e-4
% 8e-4
% 1e-3
% 1.2e-3
% 1.4e-3
% 1.6e-3
% 1.8e-3
% 2e-3
% 2.5e-3
% 3e-3
% 3.5e-3
% 4e-3
% 4.5e-3
% 5e-3
% 5.5e-3
% 6e-3
% 6.5e-3
% 7e-3
% 7.5e-3
% 8e-3
% 8.5e-3
% 9e-3
% 9.5e-3
% 1e-2
% 1.1e-2
% 1.2e-2];

% CONC=-5:0.25:-3.5;

% AC=[0.9,5.8,10.2]/1000;
% ACe=[0.7,2.2,1.4]/1000;
% AG=[10.5,18.7,27.2];
% AGe=[0.4,1.3,0.8];

% Pseudo-knot
% Targets=[
% -5.4133  0.226605
% -5.33417  0.248653
% -5.27251  0.286693
% -5.20946  0.32861
% -5.13435  0.365439
% -5.06851  0.406386
% -5.00685  0.465506
% -4.93174  0.528502
% -4.86792  0.58108
% -4.80285  0.668305
% -4.72852  0.741962
% -4.6667  0.838637
% -4.60164  0.945004
% -4.52653  1.04483
% -4.46286  1.13957
% -4.40181  1.25829
% -4.3247  1.37822
% -4.26087  1.51391
% -4.1972  1.65589
% -4.12271  1.79351
% -4.06043  1.95246
% -3.99459  2.12909
% -3.93432  2.28779
% -3.8572  2.46564
% -3.79338  2.62434
% -3.73109  2.80218
% -3.65599  2.97881
% -3.59216  3.15641
% -3.52911  3.32045];
% AC=10.^(Targets(:,1));
% AG=Targets(:,2);

% Adenine Riboswitch
% Targets=[
% 1e-6    0.504
% 2e-6    0.840
% 3e-6    1.155
% 4e-6    1.408
% 5e-6    1.639
% 6e-6    1.912
% 7e-6    2.017
% 8e-6    2.248
% 9e-6    2.479
% 1e-5    2.731
% 2e-5    4.265
% 3e-5    5.420
% 4e-5    6.345
% 5e-5    7.059
% 6e-5    7.626
% 7e-5    8.172
% 8e-5    8.782
% 9e-5    9.118
% 1e-4    9.412
% 2e-4    12.374
% 3e-4    13.718
% 4e-4    14.811
% 5e-4    15.756
% 6e-4    16.429
% 7e-4    17.038
% 8e-4    17.500
% 9e-4    17.941
% 1e-3    18.550];
% AC=Targets(:,1);
% AG=Targets(:,2);
ARiboTargets=[
   1.5274383e-07   1.5162026e-01
   1.6282384e-07   1.5162026e-01
   1.7474059e-07   1.5954811e-01
   1.9459780e-07   1.5954811e-01
   2.2112944e-07   1.5162026e-01
   3.1058658e-07   2.3089882e-01
   4.8092866e-07   2.3089882e-01
   5.4101218e-07   3.4981667e-01
   6.1684554e-07   3.5774452e-01
   7.3970257e-07   3.8152809e-01
   8.8108198e-07   4.2909523e-01
   1.0494832e-06   5.0837380e-01
   1.1037909e-06   5.4801308e-01
   1.1965887e-06   6.0350808e-01
   1.3103438e-06   6.1143593e-01
   1.3874523e-06   6.2729165e-01
   1.5142503e-06   7.6206521e-01
   1.5766188e-06   7.3828164e-01
   1.7149266e-06   8.1756020e-01
   1.8036690e-06   8.0963235e-01
   1.9487413e-06   9.0476662e-01
   2.0358416e-06   8.9683877e-01
   2.1340006e-06   9.0476662e-01
   2.3685246e-06   9.7611733e-01
   2.6824138e-06   1.1188187e+00
   2.8402632e-06   1.1743137e+00
   3.0175339e-06   1.2218809e+00
   3.1843751e-06   1.2773759e+00
   3.4871013e-06   1.3566544e+00
   3.6799051e-06   1.3883659e+00
   4.0162082e-06   1.4676444e+00
   4.2098514e-06   1.5072837e+00
   4.3832457e-06   1.5469230e+00
   4.6255979e-06   1.5944901e+00
   4.7677630e-06   1.6579130e+00
   4.9976427e-06   1.7054801e+00
   5.1860118e-06   1.7530473e+00
   5.6981595e-06   1.8719651e+00
   5.9129321e-06   1.9274601e+00
   6.1980267e-06   1.9829551e+00
   6.5848670e-06   2.0146665e+00
   6.6070525e-06   2.0305222e+00
   6.9023592e-06   2.1098008e+00
   7.2108648e-06   2.1811515e+00
   7.5331593e-06   2.2366465e+00
   7.7646867e-06   2.3000694e+00
   8.1117346e-06   2.3714201e+00
   8.4458386e-06   2.4586265e+00
   8.8530584e-06   2.5458329e+00
   9.2176958e-06   2.6013279e+00
   9.6946844e-06   2.7202458e+00
   1.0093987e-05   2.7757408e+00
   1.0616321e-05   2.8550193e+00
   1.1203303e-05   2.9342979e+00
   1.1664742e-05   3.0215043e+00
   1.2309692e-05   3.0928550e+00
   1.2859882e-05   3.2117729e+00
   1.3434663e-05   3.2751957e+00
   1.3941037e-05   3.3624021e+00
   1.4515236e-05   3.4733921e+00
   1.5164005e-05   3.6160935e+00
   1.5841770e-05   3.7350114e+00
   1.6328658e-05   3.8142900e+00
   1.7347786e-05   3.9332078e+00
   1.7820919e-05   3.9966307e+00
   1.8869609e-05   4.0996928e+00
   1.9779415e-05   4.2027549e+00
   1.9912921e-05   4.2265385e+00
   2.0873031e-05   4.3771678e+00
   2.1659768e-05   4.4723021e+00
   2.2551885e-05   4.5832920e+00
   2.3639234e-05   4.7259935e+00
   2.4695805e-05   4.8607670e+00
   2.5886524e-05   4.9955406e+00
   2.7043540e-05   5.1223863e+00
   2.8442964e-05   5.2571598e+00
   2.9317142e-05   5.3364384e+00
   3.0834218e-05   5.4791398e+00
   3.2429798e-05   5.6376970e+00
   3.4222860e-05   5.7962541e+00
   3.5512773e-05   5.9468834e+00
   3.7350455e-05   6.0816569e+00
   4.0219112e-05   6.3194926e+00
   4.2729326e-05   6.5097612e+00
   4.3894698e-05   6.5969676e+00
   4.6166120e-05   6.7158854e+00
   4.7585009e-05   6.8189476e+00
   5.0047393e-05   7.0092161e+00
   5.2284295e-05   7.1994847e+00
   5.5734689e-05   7.3738975e+00
   5.8030274e-05   7.5245268e+00
   6.0828229e-05   7.7068675e+00
   6.3546988e-05   7.8654246e+00
   6.6387264e-05   8.0239818e+00
   6.9588155e-05   8.2063225e+00
   7.1726907e-05   8.3093846e+00
   7.5947751e-05   8.5472203e+00
   7.8810341e-05   8.6582103e+00
   8.2610216e-05   8.8009117e+00
   8.5723925e-05   8.9277574e+00
   8.9857141e-05   9.1259538e+00
   9.5144877e-05   9.3003667e+00
   9.9063679e-05   9.4430681e+00
   1.0314389e-04   9.6650481e+00
   1.0848128e-04   9.8236052e+00
   1.1332992e-04   1.0029729e+01
   1.1720662e-04   1.0172431e+01
   1.2327172e-04   1.0338916e+01
   1.2878143e-04   1.0529184e+01
   1.3363540e-04   1.0711525e+01
   1.3913954e-04   1.0862154e+01
   1.4535848e-04   1.1052423e+01
   1.5083727e-04   1.1250619e+01
   1.6296937e-04   1.1401249e+01
   1.6854409e-04   1.1567734e+01
   1.7667052e-04   1.1718363e+01
   1.8456693e-04   1.1861064e+01
   1.9216882e-04   1.2075116e+01
   2.0143432e-04   1.2297096e+01
   2.0973095e-04   1.2447726e+01
   2.1836929e-04   1.2645922e+01
   2.2966926e-04   1.2812407e+01
   2.3832585e-04   1.3010604e+01
   2.4981684e-04   1.3192944e+01
   2.6010623e-04   1.3414924e+01
   2.7727140e-04   1.3573481e+01
   2.8966423e-04   1.3779606e+01
   3.0261097e-04   1.3993658e+01
   3.1507483e-04   1.4120503e+01
   3.1720149e-04   1.4096720e+01
   3.3137903e-04   1.4207710e+01
   3.4271456e-04   1.4382123e+01
   3.5923869e-04   1.4596175e+01
   3.7655954e-04   1.4786443e+01
   3.9206918e-04   1.5016351e+01
   4.0548075e-04   1.5111485e+01
   4.2790001e-04   1.5317610e+01
   4.4552424e-04   1.5492023e+01
   4.7333095e-04   1.5674363e+01
   4.9448680e-04   1.5872560e+01
   5.1485359e-04   1.6046973e+01
   5.3786532e-04   1.6237241e+01
   5.7336062e-04   1.6490933e+01
   6.0506206e-04   1.6657418e+01
   6.3851629e-04   1.6847686e+01
   6.6481533e-04   1.7006243e+01
   6.9686969e-04   1.7188584e+01
   7.1828758e-04   1.7362997e+01
   7.5800212e-04   1.7545337e+01
   8.1074726e-04   1.7727678e+01
   8.4130560e-04   1.7917947e+01
   8.7890833e-04   1.8052720e+01
   9.4641183e-04   1.8338123e+01
   1.0054807e-03   1.8552175e+01
];

SAMITargets=[
    0.9e-3    10.5
    5.8e-3    18.7 
    10.2e-3   27.2];
SAMIErrors=[
    0.7e-3  0.4
    2.2e-3  1.3
    1.4e-3  0.8];

% rRNA 58mer
% rRNATargets=[
%     0.107e-3    14.1
%     0.149e-3    11.0
%     0.388e-3    12.1
%     0.98e-3     10.4];
rRNA20Targets=[
   1.0802535e-05   4.4045393e+00
   1.2259251e-05   4.7604617e+00
   1.3622154e-05   5.1318589e+00
   1.5136576e-05   5.5496808e+00
   1.7177735e-05   6.0294023e+00
   1.9222059e-05   6.5864982e+00
   2.1890929e-05   7.1513315e+00
   2.4154271e-05   7.7703269e+00
   2.7028873e-05   8.4512219e+00
   3.0673701e-05   9.1011671e+00
   3.3845109e-05   9.7511123e+00
   3.8409103e-05   1.0370108e+01
   4.3131466e-05   1.0903991e+01
   4.7590905e-05   1.1321813e+01
   5.4389408e-05   1.1755110e+01
   6.0436068e-05   1.2188407e+01
   6.9069540e-05   1.2575279e+01
   7.6748242e-05   1.2946676e+01
   8.5280611e-05   1.3364498e+01
   9.6780652e-05   1.3782320e+01
   1.0754009e-04   1.4091818e+01
];

rRNA40Targets=[
   2.1801469e-05   2.8662667e+00
   2.4397110e-05   3.0675440e+00
   2.7110513e-05   3.3926843e+00
   3.0552282e-05   3.7333075e+00
   3.4189778e-05   4.1668279e+00
   3.8530283e-05   4.6622799e+00
   4.2815552e-05   5.1886975e+00
   4.7913090e-05   5.7925295e+00
   5.4760408e-05   6.4582930e+00
   6.0850762e-05   7.1085736e+00
   6.8575967e-05   7.7743371e+00
   7.6740490e-05   8.3626863e+00
   8.5275429e-05   8.8891039e+00
   9.7462245e-05   9.4000387e+00
   1.0754308e-04   9.8180763e+00
   1.2205109e-04   1.0251597e+01
   1.3658226e-04   1.0654151e+01
   1.5177269e-04   1.1025740e+01
];

rRNA60Targets=[
   3.8798857e-05   3.0203226e+00
   4.3113345e-05   3.2370968e+00
   4.7907610e-05   3.5467742e+00
   5.4369564e-05   3.8564516e+00
   6.0841721e-05   4.2745161e+00
   6.9048275e-05   4.6925806e+00
   7.6189087e-05   5.2345161e+00
   8.5860075e-05   5.7764516e+00
   9.7441196e-05   6.3958065e+00
   1.0751834e-04   7.0461290e+00
   1.2202081e-04   7.6500000e+00
   1.3654617e-04   8.1919355e+00
   1.5173030e-04   8.7493548e+00
   1.7341095e-04   9.2138710e+00
   1.9542270e-04   9.7403226e+00
   2.2334653e-04   1.0189355e+01
   2.4818298e-04   1.0591935e+01
   2.7578128e-04   1.0979032e+01
   3.1297967e-04   1.1319677e+01
   3.5023679e-04   1.1768710e+01
   3.9747801e-04   1.2093871e+01
];

rRNA150Targets=[
   9.7526854e-05   1.8795950e+00
   1.0761285e-04   2.0498517e+00
   1.2212807e-04   2.2355862e+00
   1.3666620e-04   2.4832323e+00
   1.5186368e-04   2.7773120e+00
   1.7234761e-04   3.1487811e+00
   1.9559449e-04   3.6131175e+00
   2.2354286e-04   4.1084096e+00
   2.4840115e-04   4.6965691e+00
   2.7602371e-04   5.3002064e+00
   3.1325480e-04   5.9038437e+00
   3.4808917e-04   6.5539146e+00
   3.9504072e-04   7.1111183e+00
   4.3896981e-04   7.6528441e+00
   4.9122481e-04   8.1326583e+00
   5.6141561e-04   8.5660390e+00
   6.2384583e-04   8.9065523e+00
   7.0799244e-04   9.2780214e+00
   7.8672220e-04   9.6340126e+00
   8.7420683e-04   1.0005482e+01
   9.9912170e-04   1.0361473e+01
];

% PK - 54 mM KCl
% PK54Targets=[
% -5.4133  0.226605
% -5.33417  0.248653
% -5.27251  0.286693
% -5.20946  0.32861
% -5.13435  0.365439
% -5.06851  0.406386
% -5.00685  0.465506
% -4.93174  0.528502
% -4.86792  0.58108
% -4.80285  0.668305
% -4.72852  0.741962
% -4.6667  0.838637
% -4.60164  0.945004
% -4.52653  1.04483
% -4.46286  1.13957
% -4.40181  1.25829
% -4.3247  1.37822
% -4.26087  1.51391
% -4.1972  1.65589
% -4.12271  1.79351
% -4.06043  1.95246
% -3.99459  2.12909
% -3.93432  2.28779
% -3.8572  2.46564
% -3.79338  2.62434
% -3.73109  2.80218
% -3.65599  2.97881
% -3.59216  3.15641
% -3.52911  3.32045];
% PK54Targets(:,1)=10.^PK54Targets(:,1);
PK54Targets=[
   3.9128237e-06   2.0794763e-01
   4.6494348e-06   2.3001836e-01
   5.3604445e-06   2.6588329e-01
   6.2068921e-06   3.0450706e-01
   7.4072469e-06   3.4313084e-01
   8.5399920e-06   3.7899577e-01
   9.8885100e-06   4.3417259e-01
   1.1800855e-05   4.9486709e-01
   1.3664284e-05   5.5280275e-01
   1.5686092e-05   6.3005029e-01
   1.8719636e-05   7.0729784e-01
   2.1582316e-05   8.0109843e-01
   2.5098293e-05   9.0317554e-01
   2.9952067e-05   9.9697613e-01
   3.4532454e-05   1.0935356e+00
   3.9985344e-05   1.2066480e+00
   4.7512810e-05   1.3197605e+00
   5.5015378e-05   1.4577026e+00
   6.3428545e-05   1.5901269e+00
   7.5045020e-05   1.7197924e+00
   8.7270611e-05   1.8770464e+00
   1.0105119e-04   2.0480945e+00
   1.1700780e-04   2.1970719e+00
   1.3963601e-04   2.3736377e+00
   1.8560887e-04   2.6991810e+00
   2.2150388e-04   2.8757468e+00
   2.5537712e-04   3.0440361e+00
   2.9826402e-04   3.2040489e+00
];

% PK79Targets=[
% -5.34221  0.17182
% -5.27715  0.187101
% -5.20204  0.21785
% -5.12755  0.247854
% -5.0645  0.278602
% -4.98877  0.323887
% -4.91428  0.36824
% -4.83716  0.418556
% -4.77612  0.476699
% -4.69699  0.537451
% -4.62188  0.598017
% -4.54801  0.67405
% -4.48635  0.750083
% -4.40846  0.840652
% -4.33072  0.934576
% -4.26767  1.02347
% -4.1938  1.1295
% -4.11606  1.25324
% -4.04157  1.39078
% -3.9779  1.52905
% -3.90403  1.68186
% -3.82768  1.83318
% -3.76262  1.98357
% -3.68875  2.15092
% -3.61163  2.3192
% -3.53652  2.48748];
% PK79Targets(:,1)=10.^PK79Targets(:,1);
PK79Targets=[
   4.5742672e-06   1.6318804e-01
   5.2898594e-06   1.7992528e-01
   6.2864029e-06   2.0861768e-01
   7.5388561e-06   2.3491905e-01
   8.6787158e-06   2.6600249e-01
   1.0313678e-05   3.0904110e-01
   1.2312443e-05   3.5686177e-01
   1.4698563e-05   4.0229141e-01
   1.6920956e-05   4.5728518e-01
   2.0108653e-05   5.1706102e-01
   2.3896872e-05   5.7683686e-01
   2.8398745e-05   6.5095890e-01
   3.2990912e-05   7.2508095e-01
   3.9384468e-05   8.0876712e-01
   4.6804010e-05   8.9962640e-01
   5.4372367e-05   9.8809465e-01
   6.4615443e-05   1.0885181e+00
   7.6440202e-05   1.2104608e+00
   9.1254122e-05   1.3419676e+00
   1.0552979e-04   1.4734745e+00
   1.2598120e-04   1.6217186e+00
   1.4971449e-04   1.7699626e+00
   1.7235102e-04   1.9134247e+00
   2.0481980e-04   2.0784060e+00
   2.4562647e-04   2.2362142e+00
   2.9189944e-04   2.4035866e+00
];


% SYSs={
%     'ARibo'
%     'PK_54'
%     'PK_79'
%     'rRNA_20'
%     'rRNA_40'
%     'rRNA_60'
%     'rRNA_150'};
% 
% NC=[16,12,12,4,4,4,4];

SAMI_NLPB=load('SAMI_NLPB_Gamma2.dat');

SYSs={
    'ARibo'
    'rRNA_20'
    'rRNA_40'
    'rRNA_60'
    'rRNA_150'
    'PK_NNL'
    'PK_NNL_79'
    'PK_Frozen'
    'PK_79'
    'SAMI'};

NC=[16 4 4 4 4 12 12 12 12 16];

for h=1:length(SYSs)
    SYS=SYSs{h};
for i=1:NC(h)
    CONCstring=num2str(i-1,'%d');
    % DIR=['Gamma/',SYS,'/',SYS,'_C',CONCstring];
    DIR=[SYS,'/',SYS,'_C',CONCstring];
    Gamma{h}{i}=load([DIR,'/gamma.xvg']);
    Concentration{h}{i}=load([DIR,'/concentration.xvg']);

    % Setup error windows
    EqF=0.2; % Equilibration fraction
    EBs=4; % Error Bins
    NE=size(Gamma{h}{i},1);
    Win{h}{i}=round(EqF*NE):NE;
    for j=1:EBs
        Wine{h}{i,j}=round(EqF*(j-1-EBs)*NE+NE):round(EqF*(j-EBs)*NE+NE);
    end

    mG{h}(i)=mean(Gamma{h}{i}(Win{h}{i},2));
    mC{h}(i)=mean(Concentration{h}{i}(Win{h}{i},2));
    for j=1:EBs
        mGs{h}(i,j)=mean(Gamma{h}{i}(Wine{h}{i,j},2));
        mCs{h}(i,j)=mean(Concentration{h}{i}(Wine{h}{i,j},2));
    end
    mGe{h}(i)=std(mGs{h}(i,:))/sqrt(EBs-1);
    mCe{h}(i)=std(mCs{h}(i,:))/sqrt(EBs-1);
    if (i==1)
        mDG{h}(1)=0;
        mDGs{h}(1,1:EBs)=0;
        mDGe{h}(i)=std(mDGs{h}(i,:))/sqrt(EBs-1);
    else
        mDG{h}(i)=mDG{h}(i-1)+(mG{h}(i)+mG{h}(i-1))/2*(log(mC{h}(i))-log(mC{h}(i-1)));
        mDGs{h}(i,:)=mDGs{h}(i-1,:)+(mGs{h}(i,:)+mGs{h}(i-1,:))./2.*(log(mCs{h}(i,:))-log(mCs{h}(i-1,:)));
        mDGe{h}(i)=std(mDGs{h}(i,:))/sqrt(EBs-1);
    end
end
end

try
    close(1)
end
figure(1)
Q=70;
XLIMS=[5e-7 2e-3];
YLIMS=[0 20];
clear handle1 handle2
% handle2=semilogxerrorfixwidth(AC,AG,ACe,AGe,1.1,1,'k','.'); % ,'MarkerSize',12)
handle2=semilogx(ARiboTargets(:,1),ARiboTargets(:,2),'k');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'k','r','g','c','b','m'};
for h=1
    hold on
    handle1(h)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1,6)+1},'.'); % ,'MarkerSize',12)
end
hold off
% title('Preferential interaction coefficient of Adenine Riboswitch')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
legend([handle1,handle2],'Simulation','Experiment','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(1,'ARibo.fig')
saveas(1,'ARibo.pdf')

try
    close(2)
end
figure(2)
Q=30;
XLIMS=[4e-6 1e-3];
YLIMS=[0 6];
clear handle1 handle2
% handle2=semilogxerrorfixwidth(AC,AG,ACe,AGe,1.1,1,'k','.'); % ,'MarkerSize',12)
handle2(1)=semilogx(PK54Targets(:,1),PK54Targets(:,2),'k');
hold on
handle2(2)=semilogx(PK79Targets(:,1),PK79Targets(:,2),'c');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'k','c','g','r','b','m'};
for h=6:7
    hold on
    handle1(h-5)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1-5,6)+1},'.'); % ,'MarkerSize',12)
end
for h=8:9
    hold on
    handle1(h-5)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1-7,6)+1},'o'); % ,'MarkerSize',12)
end
hold off
% title('Preferential interaction coefficient of Pseudoknot Fragments')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
% legend([handle1,handle2],'54 mM KCl Simulation','79 mM KCl Simulation','54 mM KCl Experiment','79 mM KCl Experiment','Location','Best')
legend([handle1,handle2],'54 mM KCl Simulation','79 mM KCl Simulation','54 mM KCl Rigid Simulation','79 mM KCl Rigid Simulation','54 mM KCl Experiment','79 mM KCl Experiment','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(2,'PK.fig')
saveas(2,'PK.pdf')

try
    close(3)
end
figure(3)
Q=61;
XLIMS=[1e-5 2e-3];
YLIMS=[0 15];
clear handle1 handle2
% handle2=semilogxerrorfixwidth(AC,AG,ACe,AGe,1.1,1,'k','.'); % ,'MarkerSize',12)
handle2(1)=semilogx(rRNA20Targets(:,1),rRNA20Targets(:,2),'r');
hold on
handle2(2)=semilogx(rRNA40Targets(:,1),rRNA40Targets(:,2),'m');
handle2(3)=semilogx(rRNA60Targets(:,1),rRNA60Targets(:,2),'g');
handle2(4)=semilogx(rRNA150Targets(:,1),rRNA150Targets(:,2),'b');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'r','m','g','b','c','k'};
for h=2:5
    hold on
    handle1(h-1)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1-1,6)+1},'.'); % ,'MarkerSize',12)
end
hold off
% title('Preferential interaction coefficient of Pseudoknot Fragments')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
legend([handle1,handle2],'20 mM KCl Simulation','40 mM KCl Simulation','60 mM KCl Simulation','150 mM KCl Simulation','20 mM KCl Experiment','40 mM KCl Experiment','60 mM KCl Experiment','150 mM KCl Experiment','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(3,'rRNA.fig')
saveas(3,'rRNA.pdf')

try
    close(4)
end
figure(4)
Q=93;
XLIMS=[5e-6 2.5e-2];
YLIMS=[0 40];
clear handle1 handle2
handle2(1)=semilogxerrorfixwidth(SAMITargets(:,1),SAMITargets(:,2),SAMIErrors(:,1),SAMIErrors(:,2),1.1,1,'r','.'); % ,'MarkerSize',12)
% handle2(1)=semilogx(SAMITargets(:,1),SAMITargets(:,2),'r.');
hold on
handle2(2)=semilogx(SAMI_NLPB(:,1),SAMI_NLPB(:,2),'ko');
set(gca,'Box','off');
xlim(XLIMS)
ylim(YLIMS)
colors={'k','m','g','b','c','r'};
for h=10
    hold on
    handle1(h-9)=semilogxerrorfixwidth(mC{h},mG{h},mCe{h},mGe{h},1.1,0.1,colors{mod(h-1-9,6)+1},'.'); % ,'MarkerSize',12)
end
hold off
% title('Preferential interaction coefficient of Pseudoknot Fragments')
xlabel('Mg concentration [M]')
ylabel('Preferential interaction coefficient')
% legend([handle1a,handle1b,handle1c,handle2],'theta_0 = 4','theta_0 = 8','theta_0 = 12','Experiment','Location','Best')
legend([handle1,handle2],'Simulation','Explicit Solvent','nonlinear Poisson-Boltzmann','Location','Best')
xlim(XLIMS)
ylim(YLIMS)
set(gca,'Box','off');
axes('Color','none',...
     'YLim',YLIMS/Q,...            %#   ... and a different scale
     'YAxisLocation','right',...  %#   ... located on the right
     'XTick',[],...               %#   ... with no x tick marks
     'Box','off');
axes('Color','none',...
     'XLim',XLIMS,...            %#   ... and a different scale
     'XScale','log',...
     'YTick',[],...
     'Box','on');
% http://stackoverflow.com/questions/2676004/different-right-and-left-axes-in-a-matlab-plot

saveas(4,'SAMI.fig')
saveas(4,'SAMI.pdf')