#! /bin/bash

GROMDIR=~/Programs/gromacs-5.0/float/bin
echo -e "[ gmx sucks ]\n508 725" > ndx.ndx

$GROMDIR/gmx distance -f Clean/traj.0.xtc -s Clean/sys.0.tpr -oall hi.xvg -xvg none -n ndx.ndx
