#! /bin/bash -l
# Written by Ryan Hayes 2010-08-20 to test the recompiled version of gromacs.

module load intel/2013.1.039
module load openmpi/1.6.5-intel

# mpiexec -n 16 ./md_rnaions.cex > output 2> error &
mpiexec -bynode -n 1 -x OMP_NUM_THREADS=8 ./md_rnaions.cex > output 2> error &
