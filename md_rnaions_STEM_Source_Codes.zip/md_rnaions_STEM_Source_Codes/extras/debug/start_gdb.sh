#! /bin/bash -l

EXECUTABLE=/shared.scratch/rlh6/V33/md_rnaions.cex
HOST=`hostname | awk -F. '{print $1}'`
PIDFILE=pid.dat
HOSTPIDFILE=pid.$HOST.dat

grep PID error > $PIDFILE
grep $HOST $PIDFILE > $HOSTPIDFILE

PIDs=(`awk '{print $2}' $HOSTPIDFILE`)
RANKs=(`awk '{print $4}' $HOSTPIDFILE`)

for i in `awk 'BEGIN {for (i=0;i<'${#PIDs[@]}';i++) {print i}}'`
do
  # gdb $MDRUN $PID &
  # sleep 3
  PID=${PIDs[$i]}
  RANK=${RANKs[$i]}
  screen -d -m -S "P$RANK" bash -l -c "gdb $EXECUTABLE $PID"
done

for i in `awk 'BEGIN {for (i=0;i<'${#PIDs[@]}';i++) {print i}}'`
do
  # echo $i
  # screen -S "P$i" -X stuff "set logging file debug.$i.log"$'\n'
  # screen -S "P$i" -X stuff "set logging on"$'\n'
  # screen -S "P$i" -X stuff "source debug.init"$'\n'
  RANK=${RANKs[$i]}
  screen -S "P$RANK" -p 0 -X stuff "set logging file debug.$RANK.log
"
  screen -S "P$RANK" -p 0 -X stuff "source debug.init
"
done
