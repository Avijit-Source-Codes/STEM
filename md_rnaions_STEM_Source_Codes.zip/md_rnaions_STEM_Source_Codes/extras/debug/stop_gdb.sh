#! /bin/bash

IDs=`screen -ls | grep Detached | grep P | awk -F. '{print $1}'`

for ID in $IDs
do
  screen -S $ID -X quit
done
