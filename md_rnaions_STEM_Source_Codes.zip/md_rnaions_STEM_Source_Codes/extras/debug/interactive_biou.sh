qsub -q interactive -I -V -l nodes=1:ppn=32
