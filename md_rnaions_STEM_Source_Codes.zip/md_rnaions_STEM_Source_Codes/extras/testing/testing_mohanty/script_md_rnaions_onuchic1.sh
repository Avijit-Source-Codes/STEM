SYS=DNA

DIR=`pwd`
EXE=../md_rnaions/src/md_rnaions.cex

export OMP_NUM_THREADS=8

#### for more than one args, use ARG1, ARG2, ARG3,...

# ARGS=$DIR/input/${SYS}1.mdp
# echo "Starting $ARGS at `date`" > outfiles/log0
# $EXE $ARGS 

# ls -l outfiles > outfiles_snapshot0

# ARGS=$DIR/input/${SYS}2.mdp
# echo "Starting $ARGS at `date`" > outfiles/log1
# $EXE $ARGS 

# ls -l outfiles > outfiles_snapshot1

# ARGS=$DIR/input/${SYS}3.mdp
# echo "Starting $ARGS at `date`" > outfiles/log2
# $EXE $ARGS 

ARGS=$DIR/${SYS}.mdp
$EXE $ARGS 
