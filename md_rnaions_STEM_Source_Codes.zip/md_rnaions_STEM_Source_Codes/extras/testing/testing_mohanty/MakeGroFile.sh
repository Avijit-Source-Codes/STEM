#! /bin/bash

XYZQ=DNA.xyzq
N=`wc -l $XYZQ | awk '{print $1}'`

awk 'BEGIN {
  print "Comment line. Pretty much useless.";
  print '$N';
} {
  printf("%5d DNA  P   %5d%8.3f%8.3f%8.3f\n",NR,NR,$1,$2,$3);
} END {
  print "   100.000   100.000   100.000"
}' $XYZQ > DNA.gro
