#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module load ibm
module load openmpi/1.6.5-ibm

export EDIR=../md_rnaions/src
JOBNAME=script_md_rnaions_biou
# QUEUE=serial
QUEUE=parallel
export NODES=10
PPN=32
WALLTIME=28800
# WALLTIME=86400

WORKDIR=`pwd`

export PROCS=`awk 'BEGIN {print '$NODES'*'$PPN'}'`

SCRIPT=script_md_rnaions_biou.sh
export INPUT=polyU_ana_pl2.mdp
QSUBOPTIONS="-N $JOBNAME -q $QUEUE -l nodes=$NODES:ppn=$PPN,walltime=$WALLTIME -d $WORKDIR -V"
JOBID=`qsub $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`
