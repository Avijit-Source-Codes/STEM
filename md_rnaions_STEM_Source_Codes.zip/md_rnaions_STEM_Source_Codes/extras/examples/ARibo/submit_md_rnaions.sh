#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module load intel/2013.1.039
module load openmpi/1.6.5-intel

JOBNAME=script_md_rnaions
QUEUE=commons
# QUEUE=scavenge
export NODES=8
ReqNODES=`awk 'BEGIN {if('$NODES'>1){print '$NODES'}else{print 2}}'`
PPN=8
WALLTIME=86400

WORKDIR=`pwd`
WALLTIME_M=`awk 'BEGIN {print '$WALLTIME'/60}'`

export PROCS=`awk 'BEGIN {print '$NODES'*'$PPN'}'`

SCRIPT=script_md_rnaions.sh
export EXE=../md_rnaions/src/md_rnaions.cex

export INPUT=ARibo_1.mdp
QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$ReqNODES --ntasks-per-node=$PPN --time=$WALLTIME_M --workdir=$WORKDIR --export=ALL"
JOBID=`sbatch $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`

export INPUT=ARibo_2.mdp
QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$ReqNODES --ntasks-per-node=$PPN --time=$WALLTIME_M --workdir=$WORKDIR --export=ALL"
JOBID=`sbatch $QSUBOPTIONS $SCRIPT`
JOBID=`echo $JOBID | awk '{print $4}'`
