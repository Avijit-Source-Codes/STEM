#! /bin/bash -l

module load intel/2013.1.039
module load openmpi/1.6.5-intel

# GDIR="/Users/ryanduck/Programs/gromacs-5.0/float/bin"
GDIR="/home/rlh6/Programs/gromacs-4.6.5/float/bin"

SYS=4KQY
NGRO=$SYS.gro
NDX=$SYS.ndx

echo -e "keep 0\na H*\nr G* & a N3 O6 N7\nr A* & a N1 N3 N7\nr C* & a O2 N3\nr U* & a O2 O4\n2 | 3 | 4 | 5\ndel 5\ndel 4\ndel 3\ndel 2\na N1 C2 N2 O2 N3 C4 N4 O4 C5 C6 N6 O6 N7 C8 N9\n!2\n3 & 4\ndel 4\ndel 3\n1 | 2 | 3\n!4\ndel 4\nname 1 Donor\nname 2 Acceptor\nname 3 OtherBase\nname 4 Other\nq\n" | $GDIR/make_ndx -f $NGRO -o $NDX
rm \#*
