#! /bin/bash
# Written 2015-01-08 to get residue-residue contacts

PDIR=../2_Hbond
GRO=$PDIR/4KQY.gro
GROF=$PDIR/4KQY_fold.gro
NDX=$PDIR/4KQY.ndx
CONTACTS=$PDIR/4KQY.contacts.ndx
TOP=$PDIR/4KQY.top
DCA=top200mapd.di

# Number of DCA contacts
N=100

# Energetics
PF=2.5
WIDTH=0.15
DIST=0.55

HB_PF=4.5
HB_WIDTH=0.02

# cp $GRO ./

awk 'BEGIN {
  DIRECTIVE="null";
  i=0;
} {
  if (FILENAME=="'$DCA'") {
    if (i<'$N' && $1+2<$2) {
      i++;
      DCA1[i]=$1+0;
      DCA2[i]=$2+0;
    }
  } else if (FILENAME=="'$GRO'") {
    if (NF>3 && NR>2) {
      RNUM=(substr($0,1,5)+0);
      RES[NR-2]=RNUM;
      RNAM=$2;
      RNAME=substr(RNAM,1,1);
      if (RNAME=="G" || RNAME=="A") {
        if ($3=="C5") {
          COM[RNUM]=$4;
        }
      } else {
        if ($3=="N3") {
          COM[RNUM]=$4;
        }
      }
      
      if (RNAME=="G") {
        if ($3=="HN1" || $3=="HN21" || $3=="HN22") {
          NDONOR[RNUM]+=1;
          DONOR[RNUM,NDONOR[RNUM]]=$4;
        } else if ($3=="N3" || $3=="O6" || $3=="N7") {
          NACCEPT[RNUM]+=1;
          ACCEPT[RNUM,NACCEPT[RNUM]]=$4;
        }
      }
      if (RNAME=="A") {
        if ($3=="HN61" || $3=="HN62") {
          NDONOR[RNUM]+=1;
          DONOR[RNUM,NDONOR[RNUM]]=$4;
        } else if ($3=="N1" || $3=="N3" || $3=="N7") {
          NACCEPT[RNUM]+=1;
          ACCEPT[RNUM,NACCEPT[RNUM]]=$4;
        }
      }
      if (RNAME=="C") {
        if ($3=="HN41" || $3=="HN42") {
          NDONOR[RNUM]+=1;
          DONOR[RNUM,NDONOR[RNUM]]=$4;
        } else if ($3=="O2" || $3=="N3") {
          NACCEPT[RNUM]+=1;
          ACCEPT[RNUM,NACCEPT[RNUM]]=$4;
        }
      }
      if (RNAME=="U") {
        if ($3=="HN3") {
          NDONOR[RNUM]+=1;
          DONOR[RNUM,NDONOR[RNUM]]=$4;
        } else if ($3=="O2" || $3=="O4") {
          NACCEPT[RNUM]+=1;
          ACCEPT[RNUM,NACCEPT[RNUM]]=$4;
        }
      }
          
    }
  } else {
    if ($1=="[") {
      DIRECTIVE=$2;
    }
    if (DIRECTIVE=="pairs" || DIRECTIVE=="exclusions") {
      if ($1=="[" || substr($1,1,1)==";") {
        print $0;
      } else if (NF>0) {
        EPS=$4;
        R12=$7;
        if (!(RES[$1]+2<RES[$2])) {
          print $0;
        }
      } else {
        for (i=1; i<='$N'; i++) {
          R1=DCA1[i];
          R2=DCA2[i];
          if (DIRECTIVE=="exclusions") {
            print COM[DCA1[i]],COM[DCA2[i]];
            for (j=1; j<=NDONOR[R1]; j++) {
              for (k=1; k<=NACCEPT[R2]; k++) {
                print DONOR[R1,j],ACCEPT[R2,k];
              }
            }
            for (j=1; j<=NDONOR[R2]; j++) {
              for (k=1; k<=NACCEPT[R1]; k++) {
                print DONOR[R2,j],ACCEPT[R1,k];
              }
            }
          } else {
            print COM[R1],COM[R2],6,'$PF','$DIST','$WIDTH',R12;
            for (j=1; j<=NDONOR[R1]; j++) {
              for (k=1; k<=NACCEPT[R2]; k++) {
                print DONOR[R1,j],ACCEPT[R2,k],5,'$HB_PF',0.00,'$HB_WIDTH';
              }
            }
            for (j=1; j<=NDONOR[R2]; j++) {
              for (k=1; k<=NACCEPT[R1]; k++) {
                print DONOR[R2,j],ACCEPT[R1,k],5,'$HB_PF',0.00,'$HB_WIDTH';
              }
            }
          }
        }
        DIRECTIVE="null";
        print $0
      }
    } else {
      print $0;
    }
  }
}' $DCA $GRO $TOP > 4KQY.top

cp $PDIR/ta* $GRO $GROF $NDX $CONTACTS ./
