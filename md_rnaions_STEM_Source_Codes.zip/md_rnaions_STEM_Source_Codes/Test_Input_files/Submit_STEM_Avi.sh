#!/bin/bash

#SBATCH --job-name=script_md_rnaions
#SBATCH --account=commons
#SBATCH --partition=commons  # Working partition
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=23:59:00  # Valid time format

echo "My job ran on:"
echo $SLURM_NODELIST

# Purge all modules before loading required ones
module purge
salloc -N 1 --cpus-per-task=16 --time=4:00:00
module load GCC/13.2.0 OpenMPI/4.1.6

# Load only the necessary and compatible modules
#module load intel-compilers/2023.2.1 impi/2021.10.0  # Intel MPI for compatibility

export OMP_NUM_THREADS=16

# Define program and input paths
PROG=/scratch/sr59/Avi/md_rnaions-V438_Fit_PMF/src/md_rnaions.cex
##INPUT=/scratch/sr59/Avi/Fit_PMF_Chelation/input/Adenine.mdp
INPUT=/scratch/sr59/Avi/Fit_PMF_Chelation/input/58mer_F.mdp

# Run the program using srun
srun --cpus-per-task=$OMP_NUM_THREADS $PROG $INPUT
