
#include "md.h"

#include "defines.h"

#include "parms.h"
#include "state.h"
#include "times.h"
#include "files.h"
#include "topol.h"

#include <stdlib.h>

struct_md* alloc_md(int argc, char *argv[])
{
  struct_md *md;
  md=malloc(sizeof(struct_md));
  md->parms=alloc_parms(argc,argv);
  md->state=alloc_state(md);
  // fprintf(stderr,"Warning, two different energy units in code, they are currently handled consistently, as of 2015-01-18\n");
  if (md->parms->flexible) {
    md->parms=alloc_topparms(md);
  }
  md->files=alloc_files();
  md->times=alloc_times();
  return md;
}


void free_md(struct_md* md)
{
  if (md->parms->flexible) {
    free_topparms(md->parms);
  }
  free_parms(md->parms);
  free_state(md->state);
  free_files(md->files);
  free_times(md->times);
  free(md);
}

